import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : (p0 ∧ p1) → p2) (h3 : p1 → p2) (h4 : p0 → p2) (h5 : (p1 ∧ p2) → p3) (h6 : p2 → p3) (h7 : (p0 ∧ p1) → p3) (h8 : (p0 ∧ p2) → p4) (h9 : (p2 ∧ p3) → p4) (h10 : p0 → p4) (h11 : (p0 ∧ p1) → p5) (h12 : (p0 ∧ p2) → p5) (h13 : (p2 ∧ p3) → p5) (h14 : (p0 ∧ p4) → p6) (h15 : (p0 ∧ p2) → p6) (h16 : (p0 ∧ p5) → p6) (h17 : p1 → p7) (h18 : (p5 ∧ p6) → p7) (h19 : (p1 ∧ p3) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  have f0 : p2 := h2 ⟨h0, h1⟩
  have f1 : p4 := h8 ⟨h0, f0⟩
  have f2 : p2 := h3 h1
  have f3 : p3 := h5 ⟨h1, f0⟩
  have f4 : p5 := h13 ⟨f2, f3⟩
  have f5 : p3 := h6 f2
  have f6 : p5 := h13 ⟨f0, f5⟩
  have f7 : p6 := h16 ⟨h0, f6⟩
  have f8 : p2 := h4 h0
  have f9 : p3 := h5 ⟨h1, f8⟩
  have f10 : p5 := h13 ⟨f2, f9⟩
  have f11 : p6 := h15 ⟨h0, f0⟩
  have f12 : p7 := h18 ⟨f10, f11⟩
  exact ⟨⟨f1, f4⟩, ⟨f7, f12⟩⟩

#print axioms specimen
