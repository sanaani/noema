import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : (p0 ∧ p1) → p2) (h3 : p0 → p2) (h4 : p1 → p2) (h5 : p1 → p3) (h6 : (p0 ∧ p2) → p3) (h7 : p2 → p3) (h8 : p2 → p4) (h9 : (p1 ∧ p2) → p4) (h10 : (p2 ∧ p3) → p4) (h11 : p3 → p5) (h12 : (p3 ∧ p4) → p5) (h13 : (p2 ∧ p3) → p5) (h14 : p1 → p6) (h15 : (p0 ∧ p1) → p6) (h16 : (p0 ∧ p4) → p6) (h17 : (p0 ∧ p3) → p7) (h18 : (p4 ∧ p5) → p7) (h19 : (p1 ∧ p3) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  have f0 : p2 := h4 h1
  have f1 : p2 := h2 ⟨h0, h1⟩
  have f2 : p3 := h6 ⟨h0, f1⟩
  have f3 : p4 := h10 ⟨f0, f2⟩
  have f4 : p2 := h3 h0
  have f5 : p5 := h13 ⟨f4, f2⟩
  have f6 : p3 := h7 f4
  have f7 : p4 := h10 ⟨f0, f6⟩
  have f8 : p6 := h16 ⟨h0, f7⟩
  have f9 : p3 := h6 ⟨h0, f4⟩
  have f10 : p4 := h10 ⟨f1, f9⟩
  have f11 : p4 := h9 ⟨h1, f0⟩
  have f12 : p5 := h12 ⟨f6, f11⟩
  have f13 : p7 := h18 ⟨f10, f12⟩
  exact ⟨⟨f3, f5⟩, ⟨f8, f13⟩⟩

#print axioms specimen
