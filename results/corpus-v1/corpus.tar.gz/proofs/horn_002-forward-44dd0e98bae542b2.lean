import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : p1 → p2) (h3 : p0 → p2) (h4 : (p0 ∧ p1) → p2) (h5 : p1 → p3) (h6 : (p0 ∧ p2) → p3) (h7 : (p1 ∧ p2) → p3) (h8 : p1 → p4) (h9 : (p0 ∧ p1) → p4) (h10 : (p1 ∧ p3) → p4) (h11 : (p1 ∧ p4) → p5) (h12 : p2 → p5) (h13 : (p1 ∧ p3) → p5) (h14 : p3 → p6) (h15 : (p1 ∧ p5) → p6) (h16 : p4 → p6) (h17 : (p1 ∧ p2) → p7) (h18 : (p3 ∧ p6) → p7) (h19 : (p0 ∧ p5) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  have f0 : p4 := h8 h1
  have f1 : p2 := h3 h0
  have f2 : p3 := h6 ⟨h0, f1⟩
  have f3 : p4 := h10 ⟨h1, f2⟩
  have f4 : p5 := h11 ⟨h1, f3⟩
  have f5 : p2 := h4 ⟨h0, h1⟩
  have f6 : p3 := h6 ⟨h0, f5⟩
  have f7 : p5 := h13 ⟨h1, f6⟩
  have f8 : p6 := h15 ⟨h1, f7⟩
  have f9 : p3 := h5 h1
  have f10 : p5 := h13 ⟨h1, f9⟩
  have f11 : p6 := h15 ⟨h1, f10⟩
  have f12 : p7 := h18 ⟨f2, f11⟩
  exact ⟨⟨f0, f4⟩, ⟨f8, f12⟩⟩

#print axioms specimen
