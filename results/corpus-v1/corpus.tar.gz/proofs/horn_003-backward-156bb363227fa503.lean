import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : p1 → p2) (h3 : p0 → p2) (h4 : (p0 ∧ p1) → p2) (h5 : p2 → p3) (h6 : (p1 ∧ p2) → p3) (h7 : p0 → p3) (h8 : (p1 ∧ p3) → p4) (h9 : (p2 ∧ p3) → p4) (h10 : (p1 ∧ p2) → p4) (h11 : (p2 ∧ p4) → p5) (h12 : (p1 ∧ p2) → p5) (h13 : (p0 ∧ p4) → p5) (h14 : (p3 ∧ p5) → p6) (h15 : (p1 ∧ p3) → p6) (h16 : (p0 ∧ p2) → p6) (h17 : p0 → p7) (h18 : (p0 ∧ p5) → p7) (h19 : (p3 ∧ p6) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  constructor
  · constructor
    · apply h9
      constructor
      · apply h2
        exact h1
      · apply h7
        exact h0
    · apply h11
      constructor
      · apply h3
        exact h0
      · apply h10
        constructor
        · exact h1
        · apply h4
          constructor
          · exact h0
          · exact h1
  · constructor
    · apply h16
      constructor
      · exact h0
      · apply h2
        exact h1
    · apply h18
      constructor
      · exact h0
      · apply h11
        constructor
        · apply h2
          exact h1
        · apply h8
          constructor
          · exact h1
          · apply h5
            apply h2
            exact h1

#print axioms specimen
