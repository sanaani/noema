import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : p1 → p2) (h3 : p0 → p2) (h4 : (p0 ∧ p1) → p2) (h5 : p2 → p3) (h6 : (p1 ∧ p2) → p3) (h7 : p0 → p3) (h8 : (p1 ∧ p3) → p4) (h9 : (p2 ∧ p3) → p4) (h10 : (p1 ∧ p2) → p4) (h11 : (p2 ∧ p4) → p5) (h12 : (p1 ∧ p2) → p5) (h13 : (p0 ∧ p4) → p5) (h14 : (p3 ∧ p5) → p6) (h15 : (p1 ∧ p3) → p6) (h16 : (p0 ∧ p2) → p6) (h17 : p0 → p7) (h18 : (p0 ∧ p5) → p7) (h19 : (p3 ∧ p6) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  have f0 : p2 := h4 ⟨h0, h1⟩
  have f1 : p3 := h6 ⟨h1, f0⟩
  have f2 : p4 := h8 ⟨h1, f1⟩
  have f3 : p2 := h2 h1
  have f4 : p3 := h6 ⟨h1, f3⟩
  have f5 : p4 := h9 ⟨f3, f4⟩
  have f6 : p5 := h13 ⟨h0, f5⟩
  have f7 : p3 := h5 f3
  have f8 : p2 := h3 h0
  have f9 : p3 := h7 h0
  have f10 : p4 := h9 ⟨f8, f9⟩
  have f11 : p5 := h13 ⟨h0, f10⟩
  have f12 : p6 := h14 ⟨f7, f11⟩
  have f13 : p3 := h6 ⟨h1, f8⟩
  have f14 : p5 := h12 ⟨h1, f3⟩
  have f15 : p6 := h14 ⟨f13, f14⟩
  have f16 : p7 := h19 ⟨f1, f15⟩
  exact ⟨⟨f2, f6⟩, ⟨f12, f16⟩⟩

#print axioms specimen
