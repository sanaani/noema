import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : (p0 ∧ p1) → p2) (h3 : p0 → p2) (h4 : p1 → p2) (h5 : p1 → p3) (h6 : (p0 ∧ p2) → p3) (h7 : p2 → p3) (h8 : p2 → p4) (h9 : (p1 ∧ p2) → p4) (h10 : (p2 ∧ p3) → p4) (h11 : p3 → p5) (h12 : (p3 ∧ p4) → p5) (h13 : (p2 ∧ p3) → p5) (h14 : p1 → p6) (h15 : (p0 ∧ p1) → p6) (h16 : (p0 ∧ p4) → p6) (h17 : (p0 ∧ p3) → p7) (h18 : (p4 ∧ p5) → p7) (h19 : (p1 ∧ p3) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  constructor
  · constructor
    · apply h9
      constructor
      · exact h1
      · apply h3
        exact h0
    · apply h12
      constructor
      · apply h5
        exact h1
      · apply h8
        apply h3
        exact h0
  · constructor
    · apply h14
      exact h1
    · apply h19
      constructor
      · exact h1
      · apply h5
        exact h1

#print axioms specimen
