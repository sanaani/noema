import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : p1 → p2) (h3 : (p0 ∧ p1) → p2) (h4 : p0 → p2) (h5 : p0 → p3) (h6 : (p1 ∧ p2) → p3) (h7 : (p0 ∧ p2) → p3) (h8 : (p1 ∧ p2) → p4) (h9 : p1 → p4) (h10 : (p0 ∧ p1) → p4) (h11 : (p0 ∧ p2) → p5) (h12 : p3 → p5) (h13 : p2 → p5) (h14 : p0 → p6) (h15 : (p1 ∧ p5) → p6) (h16 : (p2 ∧ p5) → p6) (h17 : (p1 ∧ p5) → p7) (h18 : p3 → p7) (h19 : (p4 ∧ p6) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  constructor
  · constructor
    · apply h8
      constructor
      · exact h1
      · apply h3
        constructor
        · exact h0
        · exact h1
    · apply h12
      apply h7
      constructor
      · exact h0
      · apply h2
        exact h1
  · constructor
    · apply h15
      constructor
      · exact h1
      · apply h11
        constructor
        · exact h0
        · apply h3
          constructor
          · exact h0
          · exact h1
    · apply h19
      constructor
      · apply h8
        constructor
        · exact h1
        · apply h2
          exact h1
      · apply h16
        constructor
        · apply h4
          exact h0
        · apply h13
          apply h4
          exact h0

#print axioms specimen
