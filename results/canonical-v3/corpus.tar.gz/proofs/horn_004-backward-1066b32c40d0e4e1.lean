import Lean
set_option maxHeartbeats 200000
set_option linter.unusedVariables false
theorem specimen (p0 p1 p2 p3 p4 p5 p6 p7 : Prop) (h0 : p0) (h1 : p1) (h2 : p1 → p2) (h3 : p0 → p2) (h4 : (p0 ∧ p1) → p2) (h5 : (p0 ∧ p2) → p3) (h6 : p1 → p3) (h7 : (p0 ∧ p1) → p3) (h8 : p0 → p4) (h9 : (p0 ∧ p2) → p4) (h10 : (p0 ∧ p3) → p4) (h11 : p4 → p5) (h12 : p1 → p5) (h13 : (p0 ∧ p2) → p5) (h14 : p4 → p6) (h15 : (p0 ∧ p1) → p6) (h16 : (p3 ∧ p4) → p6) (h17 : p6 → p7) (h18 : (p0 ∧ p3) → p7) (h19 : (p0 ∧ p4) → p7) : ((p4 ∧ p5) ∧ (p6 ∧ p7)) := by
  constructor
  · constructor
    · apply h8
      exact h0
    · apply h11
      apply h10
      constructor
      · exact h0
      · apply h5
        constructor
        · exact h0
        · apply h3
          exact h0
  · constructor
    · apply h16
      constructor
      · apply h6
        exact h1
      · apply h10
        constructor
        · exact h0
        · apply h5
          constructor
          · exact h0
          · apply h4
            constructor
            · exact h0
            · exact h1
    · apply h19
      constructor
      · exact h0
      · apply h9
        constructor
        · exact h0
        · apply h4
          constructor
          · exact h0
          · exact h1

#print axioms specimen
