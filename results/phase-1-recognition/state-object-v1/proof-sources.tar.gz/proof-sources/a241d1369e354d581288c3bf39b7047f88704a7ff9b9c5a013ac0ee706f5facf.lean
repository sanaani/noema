import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- And so $(u+v+w)^2\ge 3(uv+vw+wu)$ -/
theorem lean_workbook_plus_63366 (u v w : ℝ) : (u + v + w) ^ 2 ≥ 3 * (u * v + v * w + w * u)   := by
  /-
  We need to show that for any real numbers \( u \), \( v \), and \( w \), the inequality \((u + v + w)^2 \geq 3(uv + vw + wu)\) holds. This can be achieved by expanding the left-hand side and comparing it with the right-hand side. The key insight is that the square of any real number is non-negative, which will help us establish the inequality.
  1. Start by expanding \((u + v + w)^2\).
  2. Simplify the expanded expression to compare it with \(3(uv + vw + wu)\).
  3. Use the non-negativity of squares to show that the left-hand side is always greater than or equal to the right-hand side.
  -/
  -- Expand the left-hand side using the square formula for each term.
  simp only [sq]
  -- Use non-negative arithmetic to prove the inequality.
  -- Specifically, we use the fact that the square of any real number is non-negative.
  nlinarith [sq_nonneg (u + v + w), sq_nonneg (u - v), sq_nonneg (v - w), sq_nonneg (w - u)]
