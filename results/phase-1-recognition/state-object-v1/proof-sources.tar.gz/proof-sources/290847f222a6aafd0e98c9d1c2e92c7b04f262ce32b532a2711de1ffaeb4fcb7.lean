import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- While exploring a cave, Carl comes across a collection of $5$ -pound rocks worth $\$14$ each, $4$ -pound rocks worth $\$11$ each, and $1$ -pound rocks worth $\$2$ each. There are at least $20$ of each size. He can carry at most $18$ pounds. What is the maximum value, in dollars, of the rocks he can carry out of the cave? -/
theorem lean_workbook_plus_5257 (r₁ r₂ r₃ : ℕ) (h₁ : 20 ≤ r₁) (h₂ : 20 ≤ r₂) (h₃ : 20 ≤ r₃) (h₄ : r₁ + r₂ + r₃ ≤ 18) : 14 * r₁ + 11 * r₂ + 2 * r₃ ≤ 50   := by
  /-
  To solve the problem, we need to determine the maximum value of the rocks Carl can carry out of the cave. Carl can carry at most 18 pounds, and there are at least 20 rocks of each size (5-pound, 4-pound, and 1-pound). The value of each rock is given as follows:
  - 5-pound rocks worth $14 each
  - 4-pound rocks worth $11 each
  - 1-pound rocks worth $2 each
  Given that Carl can carry at most 18 pounds, we need to find the combination of rocks that maximizes the total value while ensuring the total weight does not exceed 18 pounds. We will use the constraints and the value of each rock to calculate the maximum possible value.
  -/
  -- We need to show that the total value of the rocks Carl can carry is at most $50.
  have h₅ : 14 * r₁ + 11 * r₂ + 2 * r₃ ≤ 50 := by
    -- Using the constraints and the value of each rock, we calculate the maximum possible value.
    -- We know that Carl can carry at most 18 pounds, and there are at least 20 rocks of each size.
    -- The value of each rock is given as follows:
    -- - 5-pound rocks worth $14 each
    -- - 4-pound rocks worth $11 each
    -- - 1-pound rocks worth $2 each
    -- We need to find the combination of rocks that maximizes the total value while ensuring the total weight does not exceed 18 pounds.
    omega
  -- The result from the above calculation is that the total value of the rocks Carl can carry is at most $50.
  exact h₅
