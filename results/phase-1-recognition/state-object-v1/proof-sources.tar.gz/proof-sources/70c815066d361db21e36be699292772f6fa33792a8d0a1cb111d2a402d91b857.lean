import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $ \cos\theta = \cos\theta$ -/
theorem lean_workbook_302 : cos θ = cos θ  := by
  /-
  To prove that \(\cos \theta = \cos \theta\), we observe that this statement is trivially true due to the reflexive property of equality. Specifically, the statement \(\cos \theta = \cos \theta\) holds for any real number \(\theta\) because the cosine function is defined for all real numbers.
  -/
  -- Use the reflexive property of equality to show that cos θ = cos θ.
  rw [show cos θ = cos θ by rfl]
