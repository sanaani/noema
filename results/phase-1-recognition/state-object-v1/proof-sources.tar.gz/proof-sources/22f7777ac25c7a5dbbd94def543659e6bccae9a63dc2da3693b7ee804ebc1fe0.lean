import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c>0$ such that $a^2b^2 +b^2c^2 +c^2a^2=1$ .Prove that $a+b+c+ab+bc+ca\geq3$ -/
theorem lean_workbook_plus_68017 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) (h : a^2 * b^2 + b^2 * c^2 + c^2 * a^2 = 1) : a + b + c + a * b + b * c + c * a ≥ 3   := by
  /-
  Given \(a, b, c > 0\) such that \(a^2b^2 + b^2c^2 + c^2a^2 = 1\), we need to prove that \(a + b + c + ab + bc + ca \geq 3\).
  1. **Normalization and Simplification**: The given conditions are already in a simplified form.
  2. **Non-linear Arithmetic**: Using non-linear arithmetic, we can deduce the inequality by considering the non-negativity of squares and other algebraic properties.
  -/
  -- Normalize the expression by expanding and simplifying it.
  ring_nf
  -- Use non-linear arithmetic to prove the inequality.
  -- We use the fact that the square of any real number is non-negative to help in the deduction.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    ha, hb, hc, habc, h, mul_pos ha hb, mul_pos hb hc, mul_pos hc ha]
