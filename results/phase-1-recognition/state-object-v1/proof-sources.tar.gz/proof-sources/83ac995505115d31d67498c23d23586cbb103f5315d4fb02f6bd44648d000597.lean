import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c$ are positive real numbers, and $a^2+b^2+c^2=1$ , prove inequality: $\frac{1}{a^2}+\frac{1}{b^2}+\frac{1}{c^2}\geq3+\frac{2(a^3+b^3+c^3)}{abc}$ . -/
theorem lean_workbook_19088 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) (h : a^2 + b^2 + c^2 = 1) : 1 / a^2 + 1 / b^2 + 1 / c^2 ≥ 3 + 2 * (a^3 + b^3 + c^3) / (a * b * c)  := by
  /-
  Given positive real numbers \(a\), \(b\), and \(c\) such that \(a^2 + b^2 + c^2 = 1\), we need to prove the inequality:
  \[
  \frac{1}{a^2} + \frac{1}{b^2} + \frac{1}{c^2} \geq 3 + \frac{2(a^3 + b^3 + c^3)}{abc}.
  \]
  Since \(a\), \(b\), and \(c\) are positive and \(a \cdot b \cdot c = 1\), we can simplify the right-hand side using the fact that \(a \cdot b \cdot c = 1\). This allows us to rewrite the inequality in a more manageable form. We then use algebraic manipulations and the non-negativity of squares to establish the inequality.
  -/
  -- Simplify the right-hand side using the fact that a * b * c = 1.
  field_simp [habc, mul_comm]
  -- Use non-negative properties of squares to establish the inequality.
  nlinarith [sq_nonneg (a - b), h, sq_nonneg (a - c), h, sq_nonneg (b - c), h]
