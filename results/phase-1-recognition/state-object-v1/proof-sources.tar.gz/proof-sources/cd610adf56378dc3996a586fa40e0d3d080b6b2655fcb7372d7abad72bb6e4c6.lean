import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove the inequality \(\frac{(a+b)(b+c)(c+a)}{8}\leq\frac{(a+b+c)^3}{27}\) where \(a, b, c > 1\). -/
theorem lean_workbook_plus_2800 (a b c : ℝ) (ha : 1 < a) (hb : 1 < b) (hc : 1 < c) : (a + b) * (b + c) * (c + a) / 8 ≤ (a + b + c) ^ 3 / 27   := by
  /-
  To prove the inequality \(\frac{(a+b)(b+c)(c+a)}{8} \leq \frac{(a+b+c)^3}{27}\) where \(a, b, c > 1\), we start by simplifying the expressions on both sides of the inequality. We use algebraic manipulations and properties of real numbers to show that the left-hand side is indeed less than or equal to the right-hand side. Specifically, we expand the cubes and simplify the terms, then use basic arithmetic and algebraic inequalities to establish the desired result.
  -/
  -- Normalize the expressions by expanding and simplifying them.
  ring_nf
  -- Use non-linear arithmetic to establish the inequality, leveraging the fact that squares of real numbers are non-negative.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b - 2), sq_nonneg (b + c - 2), sq_nonneg (c + a - 2)]
