import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- $ 0\leq a,b,c\leq \frac{1}{2} $ such that $ a+b+c=1$ prove that $ a^3+b^3+c^3+4abc\leq \frac{9}{32} $ -/
theorem lean_workbook_33506 (a b c : ℝ) (ha : 0 ≤ a ∧ a ≤ 1 / 2) (hb : 0 ≤ b ∧ b ≤ 1 / 2) (hc : 0 ≤ c ∧ c ≤ 1 / 2) (habc : a + b + c = 1) : a^3 + b^3 + c^3 + 4 * a * b * c ≤ 9 / 32  := by
  /-
  Given \(0 \leq a, b, c \leq \frac{1}{2}\) such that \(a + b + c = 1\), we need to prove that \(a^3 + b^3 + c^3 + 4abc \leq \frac{9}{32}\).
  1. Since \(a, b, c\) are non-negative and at most \(\frac{1}{2}\), we can use the fact that the sum \(a + b + c = 1\) to bound the terms.
  2. The expression \(a^3 + b^3 + c^3 + 4abc\) can be simplified and bounded using algebraic manipulations and the constraints on \(a, b, c\).
  3. By applying non-linear arithmetic (nlinarith), we can verify the inequality.
  -/
  -- Use non-linear arithmetic to verify the inequality given the constraints on a, b, c, and their sum.
  nlinarith [mul_nonneg (sub_nonneg.mpr ha.2) (sub_nonneg.mpr hb.2),
    mul_nonneg (sub_nonneg.mpr hb.2) (sub_nonneg.mpr hc.2),
    mul_nonneg (sub_nonneg.mpr hc.2) (sub_nonneg.mpr ha.2),
    mul_self_nonneg (a - 1 / 4), mul_self_nonneg (b - 1 / 4), mul_self_nonneg (c - 1 / 4),
    mul_self_nonneg (a - b), mul_self_nonneg (b - c), mul_self_nonneg (c - a)]
