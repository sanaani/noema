import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $ a+b+c \leq abc +2$ if $ a^2+b^2+c^2=2$ , $ a,b,c \in \mathbb{R}$ -/
theorem lean_workbook_plus_61933 (a b c : ℝ) (ha : a ^ 2 + b ^ 2 + c ^ 2 = 2) : a + b + c ≤ a * b * c + 2   := by
  /-
  Given \( a^2 + b^2 + c^2 = 2 \) and \( a, b, c \in \mathbb{R} \), we need to prove that \( a + b + c \leq abc + 2 \). We will use the non-linear arithmetic (nlinarith) tactic to handle this proof. The tactic will consider various inequalities and equalities involving squares and products of \( a, b, \) and \( c \) to derive the desired result.
  -/
  -- Use nlinarith to handle the non-linear arithmetic inequalities and equalities.
  -- This tactic will consider various inequalities and equalities involving squares and products of `a`, `b`, and `c` to derive the desired result.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b + c - 2)]
