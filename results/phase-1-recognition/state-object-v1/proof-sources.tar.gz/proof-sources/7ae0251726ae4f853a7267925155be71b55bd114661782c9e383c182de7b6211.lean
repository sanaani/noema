import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a, b, c \in [0;1]$ and $a^2+b^2+c^2=1$ . Prove that $\frac{2}{3}\leq a^3+2b^3+c^3\leq 2$ -/
theorem lean_workbook_39621 (a b c : ℝ) (ha : 0 ≤ a ∧ a ≤ 1) (hb : 0 ≤ b ∧ b ≤ 1) (hc : 0 ≤ c ∧ c ≤ 1) (h : a^2 + b^2 + c^2 = 1) : 2/3 ≤ a^3 + 2 * b^3 + c^3 ∧ a^3 + 2 * b^3 + c^3 ≤ 2  := by
  /-
  Given \(a, b, c \in [0;1]\) and \(a^2 + b^2 + c^2 = 1\), we need to prove that \(\frac{2}{3} \leq a^3 + 2b^3 + c^3 \leq 2\).
  1. **Lower Bound Proof**:
     - We use the non-negativity of squares to establish lower bounds for \(a^3 + 2b^3 + c^3\).
     - Specifically, we use the fact that \(a, b, c \geq 0\) and \(a^2 + b^2 + c^2 = 1\) to derive the lower bound.
  2. **Upper Bound Proof**:
     - Similarly, we use the non-negativity of squares to establish upper bounds for \(a^3 + 2b^3 + c^3\).
     - Using the constraints \(a, b, c \leq 1\) and \(a^2 + b^2 + c^2 = 1\), we derive the upper bound.
  -/
  constructor
  -- Lower bound proof
  all_goals
    nlinarith [sq_nonneg (a - 1 / 3), sq_nonneg (b - 1 / 3), sq_nonneg (c - 1 / 3),
      sq_nonneg (a - 2 / 3), sq_nonneg (b - 2 / 3), sq_nonneg (c - 2 / 3),
      sq_nonneg (a + b + c - 1)]
