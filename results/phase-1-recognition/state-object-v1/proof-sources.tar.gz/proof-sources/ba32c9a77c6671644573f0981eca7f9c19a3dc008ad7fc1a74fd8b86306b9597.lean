import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c$ be positive reals that satisfy $a+b+c=3$ . Prove that $\sqrt[3]{\frac{a}{1+26b}}+\sqrt[3]{\frac{b}{1+26c}}+\sqrt[3]{\frac{c}{1+26a}}\ge1$ -/
theorem lean_workbook_13782 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hab : a + b + c = 3) : (a / (1 + 26 * b))^(1 / 3) + (b / (1 + 26 * c))^(1 / 3) + (c / (1 + 26 * a))^(1 / 3) ≥ 1  := by
  /-
  Given positive real numbers \(a\), \(b\), and \(c\) such that \(a + b + c = 3\), we need to prove that:
  \[
  \sqrt[3]{\frac{a}{1 + 26b}} + \sqrt[3]{\frac{b}{1 + 26c}} + \sqrt[3]{\frac{c}{1 + 26a}} \ge 1
  \]
  To prove this inequality, we can use algebraic manipulation and simplification techniques. Specifically, we will normalize the expressions and apply basic arithmetic operations to compare the terms.
  -/
  -- Normalize the expressions by simplifying the fractions.
  ring_nf
  -- Use nlinarith to handle the inequality, providing necessary non-linear arithmetic proofs.
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
