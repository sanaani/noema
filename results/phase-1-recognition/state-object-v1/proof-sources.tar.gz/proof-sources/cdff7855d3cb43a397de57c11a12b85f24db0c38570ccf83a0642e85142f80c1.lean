import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $n\in \mathbb{Z}^+$ . Prove that $2^{\frac{1}{2}}\cdot 4^{\frac{1}{4}}\cdot 8^{\frac{1}{8}}\cdot...\cdot (2^n)^{\frac{1}{2^n}}<4$ -/
theorem lean_workbook_9279 (n : ℕ) : ∏ k ∈ Finset.Icc 1 n, (2^k)^(1/(2^k)) < 4  := by
  /-
  We need to prove that the product of terms \(2^{\frac{1}{2}} \cdot 4^{\frac{1}{4}} \cdot 8^{\frac{1}{8}} \cdot \ldots \cdot (2^n)^{\frac{1}{2^n}}\) is less than 4 for any positive integer \(n\). This can be expressed as:
  \[
  \prod_{k=1}^n \left(2^k\right)^{\frac{1}{2^k}} < 4
  \]
  To prove this, we will use the properties of the product and the fact that each term in the product is less than 2.
  -/
  induction n with
  | zero =>
    -- Base case: When n = 0, the product is empty, and thus 1 < 4 is trivially true.
    norm_num
  | succ n ih =>
    -- Inductive step: Assume the statement holds for n, prove it for n + 1.
    cases n with
    | zero =>
      -- Base case for the inductive step: When n = 0, the product is empty, and thus 1 < 4 is trivially true.
      norm_num
    | succ n =>
      -- Use the inductive hypothesis and properties of the product to show the statement holds for n + 1.
      simp_all [Finset.prod_Icc_succ_top, Nat.div_eq_of_lt, Nat.lt_pow_self]
      <;> norm_num
      <;> linarith
