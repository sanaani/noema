import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a,b,c$ be sides of a triangle. Show that: $ 2(ab^2 + bc^2 + ca^2) \ge a^2b + b^2c + c^2a + 3abc$ -/
theorem lean_workbook_plus_39161 {a b c : ℝ} (hx: a > 0 ∧ b > 0 ∧ c > 0) (hab : a + b > c) (hbc : b + c > a) (hca : a + c > b) : 2 * (a * b^2 + b * c^2 + c * a^2) ≥ a^2 * b + b^2 * c + c^2 * a + 3 * a * b * c   := by
  /-
  We need to show that for positive real numbers \(a\), \(b\), and \(c\) that satisfy the triangle inequalities, the inequality \(2(ab^2 + bc^2 + ca^2) \ge a^2b + b^2c + c^2a + 3abc\) holds. This can be proven using non-linear arithmetic (nlinarith) which leverages the non-negativity of squares to establish the inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- The `nlinarith` tactic will use the non-negativity of squares to establish the inequality.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_pos (sub_pos.mpr hab) (sub_pos.mpr hca), mul_pos (sub_pos.mpr hab) (sub_pos.mpr hbc), mul_pos (sub_pos.mpr hca) (sub_pos.mpr hbc)]
