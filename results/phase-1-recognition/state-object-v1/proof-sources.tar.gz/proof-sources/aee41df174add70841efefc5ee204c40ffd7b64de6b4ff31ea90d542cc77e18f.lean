import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- What is $\sum_{x=1}^{1155}{1}$ ? -/
theorem lean_workbook_3429 : ∑ x ∈ Finset.Icc 1 1155, 1 = 1155  := by
  /-
  To prove that the sum of 1 over the range from 1 to 1155 is equal to 1155, we can use the property of the sum of a constant over a finite set. Specifically, the sum of a constant \( c \) over a finite set \( S \) is equal to the product of \( c \) and the cardinality of \( S \). Here, the constant \( c \) is 1, and the finite set \( S \) is the interval from 1 to 1155. The cardinality of this interval is 1155, hence the sum is 1155.
  -/
  -- Use the property that the sum of a constant over a finite set is the product of the constant and the cardinality of the set.
  -- Here, the constant is 1, and the cardinality of the interval from 1 to 1155 is 1155.
  -- Therefore, the sum of 1 over this interval is 1155.
  simp [Finset.sum_const, Finset.card_range]
