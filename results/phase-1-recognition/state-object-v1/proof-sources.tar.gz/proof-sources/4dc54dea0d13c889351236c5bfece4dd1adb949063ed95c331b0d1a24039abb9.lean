import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c,d$ be real numbers such that $|a-b|\ge 1,|b-c|\ge 1,|c-d|\ge 1$ and $|d-a|\ge 1$ . Prove that $\ a^2+b^2+c^2+d^2\ge{1}.$ -/
theorem lean_workbook_plus_23440 (a b c d : ℝ) (h1 : abs (a - b) ≥ 1) (h2 : abs (b - c) ≥ 1) (h3 : abs (c - d) ≥ 1) (h4 : abs (d - a) ≥ 1) : a^2 + b^2 + c^2 + d^2 >= 1   := by
  /-
  Given real numbers \(a, b, c, d\) such that \(|a - b| \ge 1\), \(|b - c| \ge 1\), \(|c - d| \ge 1\), and \(|d - a| \ge 1\), we need to prove that \(a^2 + b^2 + c^2 + d^2 \ge 1\).
  To prove this, we consider the cases where each of \(a - b\), \(b - c\), \(c - d\), and \(d - a\) are either non-negative or non-positive. By the properties of absolute values, if \(|x| \ge 1\), then \(x\) must be at least 1 in absolute value. We can then use these inequalities to derive the desired result using basic algebraic manipulations and the non-negativity of squares.
  -/
  -- Consider the cases where each of the differences are non-negative or non-positive.
  cases' le_total 0 (a - b) with h₁ h₁ <;>
  cases' le_total 0 (b - c) with h₂ h₂ <;>
  cases' le_total 0 (c - d) with h₃ h₃ <;>
  cases' le_total 0 (d - a) with h₄ h₄ <;>
  -- Simplify the absolute values based on the non-negativity or non-positivity of the differences.
  simp_all only [abs_of_nonneg, abs_of_nonpos, sub_nonneg, sub_nonpos] <;>
  -- Use the non-negativity of squares and linear arithmetic to prove the inequality.
  nlinarith [sq_nonneg (a + b + c + d), sq_nonneg (a - b + c - d), sq_nonneg (a + b - c - d), sq_nonneg (a - b - c + d)]
