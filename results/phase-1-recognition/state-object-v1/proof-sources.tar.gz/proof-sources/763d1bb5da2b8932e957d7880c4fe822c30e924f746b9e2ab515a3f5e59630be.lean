import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c$ are non-negative reals such that $ab+bc+ca=3$ , show that $\frac{1}{1+a^2+b^2}+\frac{1}{1+b^2+c^2}+\frac{1}{1+c^2+a^2} \le 1$ -/
theorem lean_workbook_plus_48561 (a b c : ℝ) (hab : 0 ≤ a) (hbc : 0 ≤ b) (hca : 0 ≤ c) (habc : a * b + b * c + c * a = 3) : 1 / (1 + a ^ 2 + b ^ 2) + 1 / (1 + b ^ 2 + c ^ 2) + 1 / (1 + c ^ 2 + a ^ 2) ≤ 1   := by
  /-
  Given non-negative real numbers \(a\), \(b\), and \(c\) such that \(ab + bc + ca = 3\), we need to show that:
  \[
  \frac{1}{1 + a^2 + b^2} + \frac{1}{1 + b^2 + c^2} + \frac{1}{1 + c^2 + a^2} \leq 1
  \]
  To prove this, we will use the fact that the sum of the reciprocals of the expressions involving \(a\), \(b\), and \(c\) is bounded by 1, given the constraint on the sum of the products of \(a\), \(b\), and \(c\).
  -/
  -- We start by proving a preliminary inequality that will help us bound the sum of the reciprocals.
  have h₁ : 0 ≤ a * b := by nlinarith
  -- Using the non-negativity of a, b, and c, and the given constraint, we apply basic arithmetic and algebraic manipulations to show the desired inequality.
  have h₂ : 0 ≤ b * c := by nlinarith
  have h₃ : 0 ≤ c * a := by nlinarith
  have h₄ : 0 ≤ 1 + a ^ 2 + b ^ 2 := by nlinarith
  have h₅ : 0 ≤ 1 + b ^ 2 + c ^ 2 := by nlinarith
  have h₆ : 0 ≤ 1 + c ^ 2 + a ^ 2 := by nlinarith
  have h₇ : 0 ≤ (a - b) ^ 2 := by nlinarith
  have h₈ : 0 ≤ (b - c) ^ 2 := by nlinarith
  have h₉ : 0 ≤ (c - a) ^ 2 := by nlinarith
  have h₁₀ : 0 ≤ (1 - a * b) ^ 2 := by nlinarith
  have h₁₁ : 0 ≤ (1 - b * c) ^ 2 := by nlinarith
  have h₁₂ : 0 ≤ (1 - c * a) ^ 2 := by nlinarith
  -- Finally, we use the established inequalities to conclude the desired result.
  have h₁₃ : 1 / (1 + a ^ 2 + b ^ 2) + 1 / (1 + b ^ 2 + c ^ 2) + 1 / (1 + c ^ 2 + a ^ 2) ≤ 1 := by
    field_simp
    rw [div_le_one (by nlinarith)]
    nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
      sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1)]
  exact h₁₃
