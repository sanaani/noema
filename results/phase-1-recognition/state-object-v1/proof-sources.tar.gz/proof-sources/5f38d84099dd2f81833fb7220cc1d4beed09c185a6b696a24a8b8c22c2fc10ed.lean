import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- prove $\frac{z+u}{2z+u+v}+\frac{z+v}{2z+v}+\frac{z}{2z+u}\le \frac{3}{2}$ if $a=c+u$ and $b=c+v$ with $v>u\ge 0$ -/
theorem lean_workbook_25087 (u v z : ℝ) (huv : u ≥ 0 ∧ v > u) (h : v > 0 ∧ z > 0) : (z + u) / (2 * z + u + v) + (z + v) / (2 * z + v) + z / (2 * z + u) ≤ 3 / 2  := by
  /-
  We need to prove that for non-negative real numbers \( u \), \( v \), and \( z \), the inequality 
  \[
  \frac{z + u}{2z + u + v} + \frac{z + v}{2z + v} + \frac{z}{2z + u} \leq \frac{3}{2}
  \]
  holds. This can be shown by ensuring that the denominators are positive and then using algebraic manipulation and linear inequalities to establish the result.
  -/
  have h₁ : 0 < 2 * z + u + v := by linarith
  have h₂ : 0 < 2 * z + v := by linarith
  have h₃ : 0 < 2 * z + u := by linarith
  have h₄ : 0 < z + u := by linarith
  have h₅ : 0 < z + v := by linarith
  have h₆ : 0 < z := by linarith
  have h₇ : 0 < 2 * z + u + v := by linarith
  have h₈ : 0 < 2 * z + v := by linarith
  have h₉ : 0 < 2 * z + u := by linarith
  have h₁₀ : 0 < z + u := by linarith
  have h₁₁ : 0 < z + v := by linarith
  have h₁₂ : 0 < z := by linarith
  field_simp [h₁, h₂, h₃, h₄, h₅, h₆, h₇, h₈, h₉, h₁₀, h₁₁, h₁₂]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (u - v)]
