import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- And it suffices to show that \n $8(a+b+c)^2\geq 6(a^2+b^2+c^2)+18(ab+bc+ca);$ -/
theorem lean_workbook_5091 (a b c : ℝ) : 8 * (a + b + c) ^ 2 ≥ 6 * (a ^ 2 + b ^ 2 + c ^ 2) + 18 * (a * b + b * c + c * a)  := by
  /-
  To prove the inequality \(8(a+b+c)^2 \geq 6(a^2+b^2+c^2) + 18(ab+bc+ca)\), we start by expanding and simplifying both sides of the inequality. 
  First, expand the left-hand side:
  \[ 8(a + b + c)^2 = 8(a^2 + b^2 + c^2 + 2ab + 2bc + 2ca) \]
  Next, expand the right-hand side:
  \[ 6(a^2 + b^2 + c^2) + 18(ab + bc + ca) \]
  Now, we need to show that:
  \[ 8(a^2 + b^2 + c^2 + 2ab + 2bc + 2ca) \geq 6(a^2 + b^2 + c^2) + 18(ab + bc + ca) \]
  Simplify the inequality by subtracting \(6(a^2 + b^2 + c^2) + 18(ab + bc + ca)\) from both sides:
  \[ 8(a^2 + b^2 + c^2 + 2ab + 2bc + 2ca) - 6(a^2 + b^2 + c^2) - 18(ab + bc + ca) \geq 0 \]
  \[ 2(a^2 + b^2 + c^2) + 2ab + 2bc + 2ca \geq 0 \]
  This simplifies to:
  \[ 2(a^2 + b^2 + c^2) \geq -2ab - 2bc - 2ca \]
  Dividing both sides by 2:
  \[ a^2 + b^2 + c^2 \geq -ab - bc - ca \]
  Using the non-negativity of squares, we know:
  \[ a^2 \geq 0, \quad b^2 \geq 0, \quad c^2 \geq 0 \]
  Thus, we have:
  \[ a^2 + b^2 + c^2 \geq 0 \]
  Since \(a^2 + b^2 + c^2 \geq -ab - bc - ca\), the inequality holds.
  -/
  -- Use the non-negativity of squares to prove the inequality
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a)]
  -- Simplify the expressions using the non-negativity of squares
  <;> simp_all only [sq]
  -- Use linear arithmetic to conclude the proof
  <;> linarith
