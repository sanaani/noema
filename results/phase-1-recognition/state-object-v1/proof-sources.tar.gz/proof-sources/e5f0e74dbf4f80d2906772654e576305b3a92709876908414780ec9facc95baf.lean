import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- After using AM-GM, we just need to prove that \n $ (3a^2+b^2+c^2+bc)(3b^2+c^2+a^2+ca)(3c^2+a^2+b^2+ab) \ge 27abc(a+b)(b+c)(c+a)$ -/
theorem lean_workbook_plus_29897 (a b c : ℝ) : (3 * a ^ 2 + b ^ 2 + c ^ 2 + b * c) * (3 * b ^ 2 + c ^ 2 + a ^ 2 + c * a) * (3 * c ^ 2 + a ^ 2 + b ^ 2 + a * b) ≥ 27 * a * b * c * (a + b) * (b + c) * (c + a)   := by
  /-
  To prove the inequality \((3a^2 + b^2 + c^2 + bc)(3b^2 + c^2 + a^2 + ca)(3c^2 + a^2 + b^2 + ab) \ge 27abc(a+b)(b+c)(c+a)\), we use the non-linear arithmetic tactic `nlinarith` with specific non-negativity conditions. The key idea is to leverage the fact that the square of any real number is non-negative, which allows us to establish the inequality by considering various combinations of squares and products of \(a\), \(b\), and \(c\).
  -/
  -- Use non-linear arithmetic to prove the inequality by considering the non-negativity of squares and products.
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - b + c), sq_nonneg (b - c + a), sq_nonneg (c - a + b),
    mul_nonneg (sq_nonneg (a + b + c)) (sq_nonneg (a - b)),
    mul_nonneg (sq_nonneg (a + b + c)) (sq_nonneg (b - c)),
    mul_nonneg (sq_nonneg (a + b + c)) (sq_nonneg (c - a)),
    mul_nonneg (sq_nonneg (a - b)) (sq_nonneg (b - c)),
    mul_nonneg (sq_nonneg (b - c)) (sq_nonneg (c - a)),
    mul_nonneg (sq_nonneg (c - a)) (sq_nonneg (a - b)),
    mul_self_nonneg (a * b + b * c + c * a),
    mul_self_nonneg (a * b - b * c),
    mul_self_nonneg (b * c - c * a),
    mul_self_nonneg (c * a - a * b)]
