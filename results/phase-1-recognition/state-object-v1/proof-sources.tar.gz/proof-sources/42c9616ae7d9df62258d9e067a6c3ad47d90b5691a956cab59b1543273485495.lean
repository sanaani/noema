import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $a,b,c>0.$ Prove that\n${ \frac{a^2+b^2}{a+b+2}+\frac{b^2+c^2}{b+c+2}+\frac{c^2+a^2}{c+a+2}\geq\frac{3(a+b+c-1)}{4}}$ -/
theorem lean_workbook_14210 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : (a^2 + b^2) / (a + b + 2) + (b^2 + c^2) / (b + c + 2) + (c^2 + a^2) / (c + a + 2) ≥ (3 * (a + b + c - 1)) / 4  := by
  /-
  We need to prove that for positive real numbers \(a\), \(b\), and \(c\), the inequality 
  \[
  \frac{a^2 + b^2}{a + b + 2} + \frac{b^2 + c^2}{b + c + 2} + \frac{c^2 + a^2}{c + a + 2} \geq \frac{3(a + b + c - 1)}{4}
  \]
  holds.
  To do this, we will show that the difference between the left-hand side and the right-hand side is non-negative. We start by simplifying the expression using algebraic manipulations and then apply inequalities to show that the result is non-negative.
  -/
  have h₁ : 0 < a + b + 2 := by linarith
  have h₂ : 0 < b + c + 2 := by linarith
  have h₃ : 0 < c + a + 2 := by linarith
  have h₄ : 0 < a + b + c := by linarith
  -- We have established that all the denominators are positive, ensuring the terms are well-defined.
  have h₅ : 0 < a * b := by positivity
  have h₆ : 0 < b * c := by positivity
  have h₇ : 0 < c * a := by positivity
  -- Simplify the expression by clearing the denominators.
  field_simp
  -- Use the fact that the numerator is non-negative and the denominator is positive to conclude the inequality.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
