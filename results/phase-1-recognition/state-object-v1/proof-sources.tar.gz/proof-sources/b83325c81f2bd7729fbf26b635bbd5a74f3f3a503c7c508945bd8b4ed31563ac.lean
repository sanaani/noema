import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let a, b, c be positive real numbers. Prove that \n $ (a + b)^2 + (a + b + 4c)^2 \ge \frac{{100abc}}{{a + b + c}}$\n -/
theorem lean_workbook_32182 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : (a + b) ^ 2 + (a + b + 4 * c) ^ 2 ≥ 100 * a * b * c / (a + b + c)  := by
  /-
  To prove the inequality \((a + b)^2 + (a + b + 4c)^2 \ge \frac{100abc}{a + b + c}\) for positive real numbers \(a\), \(b\), and \(c\), we proceed as follows:
  1. **Establish non-negativity of the denominator**: Since \(a\), \(b\), and \(c\) are positive, \(a + b + c\) is also positive.
  2. **Simplify the inequality**: Clear the denominator by multiplying both sides by \((a + b + c)\).
  3. **Expand and simplify**: Expand the squares and simplify the resulting expression.
  4. **Apply non-negative terms**: Use the fact that the square of any real number is non-negative to conclude the inequality.
  -/
  -- Establish that the denominator is positive.
  have h₁ : 0 < a + b + c := by linarith
  -- Clear the denominator by multiplying both sides by (a + b + c).
  field_simp [ha.ne', hb.ne', hc.ne', h₁.ne']
  -- Rewrite the inequality using div_le_iff₀ to handle the denominator.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  -- Use non-negative terms to conclude the inequality.
  try nlinarith [sq_nonneg (a - b), sq_nonneg (a + b + 4 * c), sq_nonneg (a + b - 4 * c),
    sq_nonneg (a + b + c), sq_nonneg (a + b - c), sq_nonneg (a - b + c),
    sq_nonneg (a - b - c), sq_nonneg (a + b + 2 * c), sq_nonneg (a + b - 2 * c),
    sq_nonneg (a - b + 2 * c), sq_nonneg (a - b - 2 * c)]
