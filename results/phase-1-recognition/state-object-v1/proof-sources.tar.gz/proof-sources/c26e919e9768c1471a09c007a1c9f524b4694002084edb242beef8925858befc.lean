import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b>0 $ $$(1+a)(1+a+2b)\geq 3\sqrt{6ab}$$ -/
theorem lean_workbook_2450 (a b : ℝ) (ha : 0 < a) (hb : 0 < b) : (1 + a) * (1 + a + 2 * b) ≥ 3 * Real.sqrt (6 * a * b)  := by
  /-
  We need to show that for \( a, b > 0 \), the inequality \((1+a)(1+a+2b) \geq 3\sqrt{6ab}\) holds.
  1. **Non-negativity of Squares**: We start by noting that the square of any real number is non-negative. Therefore, we have:
     \[
     (a - b)^2 \geq 0, \quad (a + b)^2 \geq 0, \quad (a - 2b)^2 \geq 0, \quad (1 - 2a)^2 \geq 0, \quad (1 + a - 2b)^2 \geq 0
     \]
  2. **Non-negativity of Expressions**: We also note that the square root of a non-negative number is non-negative, and the product of non-negative numbers is non-negative. Thus, we have:
     \[
     \sqrt{6ab} \geq 0, \quad \sqrt{a \cdot b} \geq 0
     \]
  3. **Combining Inequalities**: Using the non-negativity properties and the given conditions \( a > 0 \) and \( b > 0 \), we can combine these inequalities to derive the desired inequality:
     \[
     (1 + a)(1 + a + 2b) \geq 3\sqrt{6ab}
     \]
  -/
  -- We use the fact that the square of any real number is non-negative.
  have h₀ := sq_nonneg (a - b) -- (a - b)^2 ≥ 0
  have h₁ := sq_nonneg (a + b) -- (a + b)^2 ≥ 0
  have h₂ := sq_nonneg (a - 2 * b) -- (a - 2b)^2 ≥ 0
  have h₃ := sq_nonneg (1 - 2 * a) -- (1 - 2a)^2 ≥ 0
  have h₄ := sq_nonneg (1 + a - 2 * b) -- (1 + a - 2b)^2 ≥ 0
  -- We also use the fact that the square root of a non-negative number is non-negative, and the product of non-negative numbers is non-negative.
  have h₅ := Real.sqrt_nonneg (6 * a * b) -- √(6ab) ≥ 0
  have h₆ := Real.sqrt_nonneg (a * b) -- √(ab) ≥ 0
  -- Using the non-negativity properties and the given conditions, we combine these inequalities to derive the desired inequality.
  nlinarith [sq_sqrt (show 0 ≤ 6 * a * b by positivity),
    mul_self_nonneg (a - b)]
