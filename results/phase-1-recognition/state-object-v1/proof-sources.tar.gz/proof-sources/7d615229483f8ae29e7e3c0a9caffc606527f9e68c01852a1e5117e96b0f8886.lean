import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c>0$ and $a^2+b^2+c^2=1$ , prove that:\n$\frac{a^3}{b^2+c}+\frac{b^3}{c^2+a}+\frac{c^3}{a^2+b} \ge \frac{\sqrt{3}}{1+a+b+c}$. -/
theorem lean_workbook_plus_44565 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) (h : a^2 + b^2 + c^2 = 1) : a^3 / (b^2 + c) + b^3 / (c^2 + a) + c^3 / (a^2 + b) ≥ Real.sqrt 3 / (1 + a + b + c)   := by
  /-
  Given \(a, b, c > 0\) and \(a^2 + b^2 + c^2 = 1\), we need to prove that:
  \[
  \frac{a^3}{b^2 + c} + \frac{b^3}{c^2 + a} + \frac{c^3}{a^2 + b} \ge \frac{\sqrt{3}}{1 + a + b + c}.
  \]
  To prove this inequality, we start by simplifying the left-hand side and comparing it with the right-hand side. We use algebraic manipulations and known inequalities to establish the desired result.
  -/
  -- Normalize the expressions by expanding and simplifying them.
  ring_nf
  -- Use non-linear arithmetic to handle the inequalities and equalities.
  nlinarith [sq_nonneg (a - b)]
