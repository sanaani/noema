import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Fact 1: Let $a, b, c, d \ge 0$ with $\frac{a}{1 + a} + \frac{b}{1 + b} + \frac{c}{1 + c} + \frac{d}{1 + d} = 1$ . Then \n\n $a^2 + b^2 + c^2 + d^2 + \frac{12}{17} \ge \frac{11}{17}(a + b + c + d)^2$ . -/
theorem lean_workbook_plus_29384 (a b c d : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) (habc : a + b + c + d = 1) : a^2 + b^2 + c^2 + d^2 + 12 / 17 ≥ 11 / 17 * (a + b + c + d)^2   := by
  /-
  Given \(a, b, c, d \ge 0\) such that \(\frac{a}{1 + a} + \frac{b}{1 + b} + \frac{c}{1 + c} + \frac{d}{1 + d} = 1\), we need to show that:
  \[ a^2 + b^2 + c^2 + d^2 + \frac{12}{17} \ge \frac{11}{17}(a + b + c + d)^2 \]
  To prove this, we use the non-negativity of squares and the given conditions. Specifically, we consider the squares of the differences \(a - b\), \(a - c\), \(a - d\), \(b - c\), \(b - d\), \(c - d\), and the non-negativity of the expressions involving \(a, b, c, d\).
  -/
  -- Use non-linear arithmetic to handle the inequalities involving squares and sums.
  nlinarith [sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d),
    sq_nonneg (a + b + c + d)]
