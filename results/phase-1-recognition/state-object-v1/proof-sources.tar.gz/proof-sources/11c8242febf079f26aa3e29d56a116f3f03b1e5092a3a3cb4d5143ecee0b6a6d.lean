import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- THQ050. $x,y, z \in R$ \n\n $7(x^2+y^2+z^2)^2+12\sum_{cyc}^{ }xy(x^2+y^2)\ge0$ -/
theorem lean_workbook_2592 (x y z : ℝ) : 7 * (x ^ 2 + y ^ 2 + z ^ 2) ^ 2 + 12 * (x * y * (x ^ 2 + y ^ 2) + y * z * (y ^ 2 + z ^ 2) + z * x * (z ^ 2 + x ^ 2)) ≥ 0  := by
  /-
  We need to show that for real numbers \( x, y, z \), the inequality \( 7(x^2 + y^2 + z^2)^2 + 12 \sum_{\text{cyc}} xy(x^2 + y^2) \geq 0 \) holds. This can be proven using non-linear arithmetic (nlinarith) by considering the non-negativity of squares and the sum of squares.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- The `nlinarith` tactic will check the non-negativity of the squares and the sum of squares.
  nlinarith [sq_nonneg (x + y + z), sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    sq_nonneg (x + y - z), sq_nonneg (y + z - x), sq_nonneg (z + x - y)]
