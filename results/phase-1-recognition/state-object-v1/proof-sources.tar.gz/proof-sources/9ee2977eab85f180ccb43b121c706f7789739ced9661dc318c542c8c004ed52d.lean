import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c\in [\frac{1}{2},2].$ Prove that \n\n $$(a- b-c)\left(\frac{1}{a}+\frac{1}{b}+\frac{1}{c}\right) \leq \frac{9}{2}$$\n\n $$(a- b+c)\left(\frac{1}{a}+\frac{1}{b}-\frac{1}{c}\right) \leq 7$$\n\n $$(a- b+c)\left(\frac{1}{a}+\frac{1}{b}+\frac{1}{c}\right) \leq \frac{21}{2}$$ -/
theorem lean_workbook_plus_67559 : ∀ a b c : ℝ, a ∈ Set.Icc (1 / 2) 2 ∧ b ∈ Set.Icc (1 / 2) 2 ∧ c ∈ Set.Icc (1 / 2) 2 → (a - b - c) * (1 / a + 1 / b + 1 / c) ≤ 9 / 2 ∧ (a - b + c) * (1 / a + 1 / b - 1 / c) ≤ 7 ∧ (a - b + c) * (1 / a + 1 / b + 1 / c) ≤ 21 / 2   := by
  /-
  Given \(a, b, c \in \left[\frac{1}{2}, 2\right]\), we need to prove three inequalities:
  1. \((a - b - c)\left(\frac{1}{a} + \frac{1}{b} + \frac{1}{c}\right) \leq \frac{9}{2}\)
  2. \((a - b + c)\left(\frac{1}{a} + \frac{1}{b} - \frac{1}{c}\right) \leq 7\)
  3. \((a - b + c)\left(\frac{1}{a} + \frac{1}{b} + \frac{1}{c}\right) \leq \frac{21}{2}\)
  -/
  intro a b c ⟨⟨ha1, ha2⟩, ⟨hb1, hb2⟩, ⟨hc1, hc2⟩⟩
  constructor
  -- Prove the first inequality: (a - b - c) * (1 / a + 1 / b + 1 / c) ≤ 9 / 2
  {
    field_simp
    (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
      ring_nf
    -- Use linear arithmetic to prove the inequality
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
    -- Additional linear arithmetic to handle the constraints
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
    -- Final linear arithmetic to complete the proof
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
  }
  constructor
  -- Prove the second inequality: (a - b + c) * (1 / a + 1 / b - 1 / c) ≤ 7
  {
    field_simp
    (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
      ring_nf
    -- Use linear arithmetic to prove the inequality
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
    -- Additional linear arithmetic to handle the constraints
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
  }
  -- Prove the third inequality: (a - b + c) * (1 / a + 1 / b + 1 / c) ≤ 21 / 2
  {
    field_simp
    (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
      ring_nf
    -- Use linear arithmetic to prove the inequality
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
    -- Additional linear arithmetic to handle the constraints
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
    -- Final linear arithmetic to complete the proof
    try nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hb1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr hb1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr hb2) (sub_nonneg.mpr hc2),
      mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hc1),
      mul_nonneg (sub_nonneg.mpr ha2) (sub_nonneg.mpr hb2)]
  }
