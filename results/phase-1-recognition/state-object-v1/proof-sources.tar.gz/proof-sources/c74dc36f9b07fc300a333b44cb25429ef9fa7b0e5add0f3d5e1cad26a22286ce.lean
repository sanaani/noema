import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- An alternative proof: Observe that the group of units $(\mathbb{Z}/d\mathbb{Z})^*$ is a subgroup of $(\mathbb{Z}/n\mathbb{Z})^*$ when $d | n$. Since the order of a subgroup divides the order of the group, $\varphi(d) | \varphi(n)$. -/
theorem lean_workbook_plus_61458 {d n : ℕ} (h : d ∣ n) : totient d ∣ totient n   := by  -- We need to show that the Euler's totient function \(\varphi(d)\) divides \(\varphi(n)\) given that \(d\) divides \(n\).
  apply totient_dvd_of_dvd
  -- By the property of Euler's totient function, \(\varphi(d)\) divides \(\varphi(n)\) whenever \(d\) divides \(n\).
  exact h
