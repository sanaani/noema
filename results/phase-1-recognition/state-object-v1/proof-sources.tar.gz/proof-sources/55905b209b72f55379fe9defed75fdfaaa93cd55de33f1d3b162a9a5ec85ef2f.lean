import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let be $ a,b\in \mathbb{R}$ and let be $ f: \mathbb{R}\rightarrow \mathbb{R}$ such that $ a\cdot f(x)+b\cdot f(1-x)=x\ (1)\ ,\ (\forall)x\in \mathbb{R}$ .\n\ni)Show that $ f(x)+f(1-x)=\frac{1}{a+b}\ ,\ (\forall)x\in \mathbb{R}\ ,\ a\neq -b$ ;\n\nii)If $ a=b$ , prove that $ (\nexists)f$ satisfying $ (1)$ ;\n\nii)If $ a\neq b$ , find $ f$ . -/
theorem lean_workbook_50503 (a b : ℝ) (f : ℝ → ℝ) (h₁ : a ≠ -b) (h₂ : ∀ x, a * f x + b * f (1 - x) = x) : ∀ x, f x + f (1 - x) = 1 / (a + b)  := by
  /-
  Given \( a, b \in \mathbb{R} \) and a function \( f: \mathbb{R} \rightarrow \mathbb{R} \) such that \( a \cdot f(x) + b \cdot f(1 - x) = x \) for all \( x \in \mathbb{R} \), we need to show that \( f(x) + f(1 - x) = \frac{1}{a + b} \) for all \( x \in \mathbb{R} \) when \( a \neq -b \).
  1. Start by introducing an arbitrary \( x \in \mathbb{R} \).
  2. Use the given functional equation \( a \cdot f(x) + b \cdot f(1 - x) = x \) to obtain the equation \( a \cdot f(x) + b \cdot f(1 - x) = x \).
  3. Use the given functional equation again with \( 1 - x \) to obtain the equation \( a \cdot f(1 - x) + b \cdot f(x) = 1 - x \).
  4. Add the two equations to eliminate the terms involving \( f \):
     \[
     (a \cdot f(x) + b \cdot f(1 - x)) + (a \cdot f(1 - x) + b \cdot f(x)) = x + (1 - x)
     \]
     Simplifying the left-hand side, we get:
     \[
     a \cdot f(x) + b \cdot f(1 - x) + a \cdot f(1 - x) + b \cdot f(x) = a + b
     \]
     Since \( a \cdot f(x) + b \cdot f(1 - x) = x \), we have:
     \[
     x + a \cdot f(1 - x) + b \cdot f(x) = a + b
     \]
  5. Isolate \( f(x) + f(1 - x) \) by dividing both sides by \( a + b \):
     \[
     f(x) + f(1 - x) = \frac{1}{a + b}
     \]
  -/
  intro x
  have h₃ := h₂ x
  have h₄ := h₂ (1 - x)
  -- Simplify the expressions involving f using the given functional equations
  field_simp [h₁, sub_eq_zero, add_eq_zero_iff_eq_neg] at *
  -- Use linear arithmetic to combine the equations and solve for f(x) + f(1 - x)
  linarith
