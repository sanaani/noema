import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given $ x \ge y \ge 0$ , that is\n\n$ \frac{x}{1+y} \ge \frac{y}{y+1}$ -/
theorem lean_workbook_plus_17723 (x y : ℝ) (hxy : x ≥ y) (hy : y ≥ 0) : (x / (1 + y)) ≥ (y / (y + 1))   := by
  /-
  Given \( x \ge y \ge 0 \), we need to show that \( \frac{x}{1+y} \ge \frac{y}{y+1} \). To prove this, we start by noting that since \( x \ge y \) and \( y \ge 0 \), the denominators \( 1 + y \) and \( y + 1 \) are positive. We then rewrite the inequality using the division property and simplify the resulting expression. Finally, we use algebraic manipulation and linear arithmetic to confirm the inequality.
  -/
  -- We need to show that x / (1 + y) ≥ y / (y + 1).
  have h₁ : x / (1 + y) ≥ y / (y + 1) := by
    -- First, we establish that the denominators are positive.
    have h₁ : 0 ≤ 1 + y := by linarith
    have h₂ : 0 ≤ y + 1 := by linarith
    -- We rewrite the inequality using the division property.
    rw [ge_iff_le]
    (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
      nlinarith
    all_goals nlinarith
  -- Finally, we conclude the proof.
  exact h₁
