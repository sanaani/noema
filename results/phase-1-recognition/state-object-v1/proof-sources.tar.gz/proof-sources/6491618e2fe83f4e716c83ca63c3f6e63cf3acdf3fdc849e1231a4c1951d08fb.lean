import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- $f(a) = a,\forall a\in\mathbb Z$ -/
theorem lean_workbook_42272 : ∃ f : ℤ → ℤ, ∀ a : ℤ, f a = a  := by
  /-
  We need to show that there exists a function \( f : \mathbb{Z} \to \mathbb{Z} \) such that for all \( a \in \mathbb{Z} \), \( f(a) = a \). We can define such a function \( f \) as the identity function, i.e., \( f(a) = a \). To verify that this function satisfies the required property, we simply observe that for any integer \( a \), \( f(a) = a \).
  -/
  -- We define the function f as the identity function.
  exact ⟨fun a => a, fun a => rfl⟩
