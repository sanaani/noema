import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $\sqrt{\frac{x^2+y^2+z^2}{3}} \ge \frac{x+y+z}{3}$. -/
theorem lean_workbook_16073 (x y z : ℝ) :
  Real.sqrt ((x ^ 2 + y ^ 2 + z ^ 2) / 3) ≥ (x + y + z) / 3  := by
  /-
  To prove that \(\sqrt{\frac{x^2 + y^2 + z^2}{3}} \ge \frac{x + y + z}{3}\), we start by applying the inequality \(\sqrt{a} \ge b\) if and only if \(a \ge b^2\). Here, \(a = \frac{x^2 + y^2 + z^2}{3}\) and \(b = \frac{x + y + z}{3}\). We need to show that \(\frac{x^2 + y^2 + z^2}{3} \ge \left(\frac{x + y + z}{3}\right)^2\).
  First, expand \(\left(\frac{x + y + z}{3}\right)^2\):
  \[
  \left(\frac{x + y + z}{3}\right)^2 = \frac{(x + y + z)^2}{9} = \frac{x^2 + y^2 + z^2 + 2xy + 2yz + 2xz}{9}
  \]
  Thus, the inequality becomes:
  \[
  \frac{x^2 + y^2 + z^2}{3} \ge \frac{x^2 + y^2 + z^2 + 2xy + 2yz + 2xz}{9}
  \]
  Multiplying both sides by 9 to clear the fraction:
  \[
  3(x^2 + y^2 + z^2) \ge x^2 + y^2 + z^2 + 2xy + 2yz + 2xz
  \]
  Simplifying the left-hand side:
  \[
  3x^2 + 3y^2 + 3z^2 \ge x^2 + y^2 + z^2 + 2xy + 2yz + 2xz
  \]
  Subtracting \(x^2 + y^2 + z^2\) from both sides:
  \[
  2x^2 + 2y^2 + 2z^2 \ge 2xy + 2yz + 2xz
  \]
  Dividing by 2:
  \[
  x^2 + y^2 + z^2 \ge xy + yz + xz
  \]
  This inequality holds because the sum of squares of real numbers is always non-negative, and the equality holds if and only if \(x = y = z\).
  -/
  -- Apply the inequality \(\sqrt{a} \ge b\) if and only if \(a \ge b^2\)
  apply le_sqrt_of_sq_le
  -- Expand and simplify the inequality
  ring_nf
  -- Use non-linear arithmetic to verify the inequality
  nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x)]
  <;>
  linarith
