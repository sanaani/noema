import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for all real $a, b, c \geq 0$ , $(a+b+c)^5\geq81abc(a^2+b^2+c^2)$ -/
theorem lean_workbook_34729 (a b c : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) : (a + b + c) ^ 5 >= 81 * a * b * c * (a ^ 2 + b ^ 2 + c ^ 2)  := by
  /-
  To prove the inequality \((a+b+c)^5 \geq 81abc(a^2+b^2+c^2)\) for all real \(a, b, c \geq 0\), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the required inequality by considering the non-negativity of certain squares and the given conditions.
  -/
  -- Use the nlinarith tactic to prove the inequality.
  -- The nlinarith tactic will consider the non-negativity of certain expressions and the given conditions to deduce the required inequality.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a ^ 2 - b ^ 2), sq_nonneg (b ^ 2 - c ^ 2), sq_nonneg (c ^ 2 - a ^ 2),
    sq_nonneg (a ^ 2 + b ^ 2), sq_nonneg (b ^ 2 + c ^ 2), sq_nonneg (c ^ 2 + a ^ 2),
    sq_nonneg (a ^ 2 - 2 * a * b + b ^ 2), sq_nonneg (b ^ 2 - 2 * b * c + c ^ 2),
    sq_nonneg (c ^ 2 - 2 * c * a + a ^ 2), sq_nonneg (a * b - b * c),
    sq_nonneg (b * c - c * a), sq_nonneg (c * a - a * b)]
