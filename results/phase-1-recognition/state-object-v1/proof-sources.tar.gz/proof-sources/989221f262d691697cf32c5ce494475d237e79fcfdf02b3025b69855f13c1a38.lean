import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b$ be reals. Prove that $$a^2+ab+b^2\geq 3(a+b-1),$$ $$a^2+ab+b^2\geq 3ab(a+b-ab),$$ $$a^2+ab+b^2\leq 3(a^2-a+1)(b^2-b+1).$$ -/
theorem lean_workbook_plus_66130 : ∀ a b : ℝ, a^2 + a * b + b^2 ≥ 3 * (a + b - 1) ∧ a^2 + a * b + b^2 ≥ 3 * a * b * (a + b - a * b) ∧ a^2 + a * b + b^2 ≤ 3 * (a^2 - a + 1) * (b^2 - b + 1)   := by
  /-
  We need to prove three inequalities involving real numbers \(a\) and \(b\):
  1. \(a^2 + ab + b^2 \geq 3(a + b - 1)\)
  2. \(a^2 + ab + b^2 \geq 3ab(a + b - ab)\)
  3. \(a^2 + ab + b^2 \leq 3(a^2 - a + 1)(b^2 - b + 1)\)
  To prove these inequalities, we will use the non-negativity of squares and algebraic manipulations. Specifically, we will use the fact that the square of any real number is non-negative, and apply this to various expressions involving \(a\) and \(b\).
  -/
  intro a b
  constructor
  -- Prove the first inequality: a^2 + ab + b^2 ≥ 3(a + b - 1)
  -- We use the non-negativity of squares of various expressions involving a and b.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (a - b), sq_nonneg (a + b - 2)]
  constructor
  -- Prove the second inequality: a^2 + ab + b^2 ≥ 3ab(a + b - ab)
  -- Similarly, we use the non-negativity of squares of various expressions involving a and b.
  nlinarith [sq_nonneg (a - b), sq_nonneg (a + b - 2 * a * b), sq_nonneg (a * b - 1), sq_nonneg (a * b - a), sq_nonneg (a * b - b)]
  -- Prove the third inequality: a^2 + ab + b^2 ≤ 3(a^2 - a + 1)(b^2 - b + 1)
  -- Again, we use the non-negativity of squares of various expressions involving a and b.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (a - b), sq_nonneg (a + b - 2), sq_nonneg (a * b - a), sq_nonneg (a * b - b), sq_nonneg (a * b - 1)]
