import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- So the LCM of $4$ and $6$ is $2 \times 2 \times 3 = 12$ -/
theorem lean_workbook_18414 :
  Nat.lcm 4 6 = 12  := by
  /-
  To prove that the least common multiple (LCM) of 4 and 6 is 12, we start by understanding the prime factorization of 4 and 6. The prime factorization of 4 is \(2^2\), and the prime factorization of 6 is \(2 \times 3\). The LCM is found by taking the highest power of each prime that appears in the factorizations of the numbers. Therefore, the LCM of 4 and 6 is \(2^2 \times 3 = 12\).
  -/
  -- Use the `decide` tactic to automatically determine the result of the LCM calculation.
  decide
