import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $5 \mid a$ and $2 \mid a$ , then $a^4 \equiv 0 \pmod{10}$ . -/
theorem lean_workbook_plus_77403 : 5 ∣ a ∧ 2 ∣ a → a^4 ≡ 0 [ZMOD 10]   := by
  /-
  Given that \(5 \mid a\) and \(2 \mid a\), we need to show that \(a^4 \equiv 0 \pmod{10}\). Since \(5 \mid a\) and \(2 \mid a\), \(a\) must be a multiple of the least common multiple (LCM) of 5 and 2, which is 10. Therefore, \(a \equiv 0 \pmod{10}\). Raising both sides to the fourth power, we get \(a^4 \equiv 0^4 \pmod{10}\), which simplifies to \(a^4 \equiv 0 \pmod{10}\).
  -/
  -- Introduce the hypothesis that 5 divides a and 2 divides a.
  rintro ⟨h₀, h₁⟩
  -- Since 5 divides a and 2 divides a, a must be a multiple of 10.
  have h₂ : a % 10 = 0 := by
    -- Use the fact that a is a multiple of 5 and 2 to conclude a % 10 = 0.
    omega
  -- Calculate the fourth power of a modulo 10, knowing a % 10 = 0.
  have h₃ : a ^ 4 % 10 = 0 := by
    -- Since a % 10 = 0, raising 0 to any power is still 0.
    simp [h₂, pow_succ, Int.mul_emod, Int.emod_emod]
  -- Conclude the proof by stating the result.
  exact h₃
