import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a\ge b\ge c$ be reals such that $a+b+c>0;~~ab+bc+ca=3.$ Prove $a+b+c+\left(2a-b-c\right)^2\ge a^2+b^2+c^2.$ -/
theorem lean_workbook_14827 (a b c : ℝ) (h : a ≥ b ∧ b ≥ c) (h2 : a + b + c > 0) (h3 : a * b + b * c + c * a = 3) : a + b + c + (2 * a - b - c) ^ 2 ≥ a ^ 2 + b ^ 2 + c ^ 2  := by
  /-
  Given real numbers \(a \ge b \ge c\) such that \(a + b + c > 0\) and \(ab + bc + ca = 3\), we need to prove that \(a + b + c + (2a - b - c)^2 \ge a^2 + b^2 + c^2\).
  First, we expand and simplify the expression \((2a - b - c)^2\). This results in:
  \[
  (2a - b - c)^2 = 4a^2 - 4b^2 - 4c^2 - 4ab - 4ac + 2b^2 + 2c^2 + 2ab + 2ac
  \]
  Next, we combine like terms:
  \[
  4a^2 - 4b^2 - 4c^2 - 4ab - 4ac + 2b^2 + 2c^2 + 2ab + 2ac = 4a^2 - 2b^2 - 2c^2
  \]
  Thus, the original inequality becomes:
  \[
  a + b + c + (4a^2 - 2b^2 - 2c^2) \ge a^2 + b^2 + c^2
  \]
  Simplifying further:
  \[
  a + b + c + 4a^2 - 2b^2 - 2c^2 \ge a^2 + b^2 + c^2
  \]
  Combining terms:
  \[
  4a^2 - 2b^2 - 2c^2 + a + b + c \ge a^2 + b^2 + c^2
  \]
  Rearranging terms:
  \[
  3a^2 - 3b^2 - 3c^2 + a + b + c \ge 0
  \]
  This inequality can be verified using non-linear arithmetic, given the constraints \(a \ge b \ge c\) and the conditions \(a + b + c > 0\) and \(ab + bc + ca = 3\).
  -/
  -- Expand and simplify the expression (2a - b - c)^2
  ring_nf
  -- Use non-linear arithmetic to verify the inequality given the constraints and conditions
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_nonneg (sub_nonneg.mpr h.1) (sub_nonneg.mpr h.2)]
