import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- 7. $ \cos^{2}x=\frac{1+\cos 2x}{2}$ -/
theorem lean_workbook_16688 (x : ℝ) : (Real.cos x)^2 = (1 + Real.cos (2 * x)) / 2  := by
  /-
  To prove the identity \(\cos^2 x = \frac{1 + \cos 2x}{2}\), we start by using the trigonometric identity for \(\cos 2x\). Specifically, we use the identity \(\cos 2x = 2\cos^2 x - 1\). We then substitute this into the right-hand side of the equation to show that it equals \(\cos^2 x\).
  -/
  -- Use the trigonometric identity for cos(2x) which is cos(2x) = 2cos^2 x - 1
  field_simp [Real.cos_sq, mul_add, mul_sub, mul_one, mul_div_cancel_left]
  -- Simplify the expression using algebraic manipulation
  <;> ring
  -- Simplify further using specific trigonometric identities
  <;> simp
  -- Finalize the simplification to show the equality
  <;> ring
