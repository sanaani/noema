import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $x$ = $a+b$ $y$ = $b+c$ $z$ = $a+c$ \n\n $\frac{1}{2}$ ( $\frac{x+z-y}{y}$ + $\frac{x+y-z}{z}$ + $\frac{y+z-x}{x}$ = $\frac{1}{2}$ ( $\frac{x}{y}$ + $\frac{y}{x}$ + $\frac{x}{z}$ + $\frac{z}{x}$ + $\frac{y}{z}$ + $\frac{x}{y}$ - $3$ ) $>=$ $\frac{1}{2}$ ( $2+2+2-3)$ = $\frac{3}{2}$ -/
theorem lean_workbook_plus_24730  (x y z : ℝ)
  (h₀ : x = a + b)
  (h₁ : y = b + c)
  (h₂ : z = a + c)
  (h₃ : 0 < x ∧ 0 < y ∧ 0 < z) :
  1 / 2 * ((x + z - y) / y + (x + y - z) / z + (y + z - x) / x) ≥ 3 / 2   := by
  /-
  Given \( x = a + b \), \( y = b + c \), and \( z = a + c \), we need to show that:
  \[
  \frac{1}{2} \left( \frac{x + z - y}{y} + \frac{x + y - z}{z} + \frac{y + z - x}{x} \right) \geq \frac{3}{2}
  \]
  First, we express the terms inside the fraction:
  \[
  \frac{x + z - y}{y} = \frac{(a + b) + (a + c) - (b + c)}{b + c} = \frac{2a}{b + c} = \frac{2x}{y}
  \]
  \[
  \frac{x + y - z}{z} = \frac{(a + b) + (b + c) - (a + c)}{a + c} = \frac{2b}{a + c} = \frac{2y}{z}
  \]
  \[
  \frac{y + z - x}{x} = \frac{(b + c) + (a + c) - (a + b)}{a + b} = \frac{2c}{a + b} = \frac{2z}{x}
  \]
  Thus, the expression becomes:
  \[
  \frac{1}{2} \left( \frac{2x}{y} + \frac{2y}{z} + \frac{2z}{x} \right)
  \]
  Next, we simplify the expression:
  \[
  \frac{1}{2} \left( \frac{2x}{y} + \frac{2y}{z} + \frac{2z}{x} \right) = \frac{1}{2} \left( 2 + 2 + 2 - 3 \right) = \frac{1}{2} \left( 3 \right) = \frac{3}{2}
  \]
  Since the simplified expression is \(\frac{3}{2}\), we conclude that:
  \[
  \frac{1}{2} \left( \frac{x + z - y}{y} + \frac{x + y - z}{z} + \frac{y + z - x}{x} \right) \geq \frac{3}{2}
  \]
  -/
  have h₄ : 0 < y := by linarith
  have h₅ : 0 < z := by linarith
  have h₆ : 0 < x := by linarith
  field_simp [h₄, h₅, h₆]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x)]
