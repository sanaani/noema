import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For the following, which values of p determine a convergent series? \n\n(a) $\Sigma_{n=1}^{\infty} \frac{1}{n^p}$ (I do not know how to make the Sigma larger and put the infinity on top and n=1 on bottom....) \n\nI know that this is our basic p-series and that it is convergent when $p > 1$ and divergent when $p \leq 1$ \n\nI think the way to prove this is to see that \n\nIf $p < 0$ , then $\lim_{n \rightarrow \infty} \frac{1}{n^p} = \infty$ \n\nIf $p = 0$ , then $\lim_{n \rightarrow \infty} \frac{1}{n^p} = 1$ \n\nIn both cases, the limit doesn't equal zero so the series' sum cannot converge. \n\nThen we can apply the integral test because $\int_1^\infty \frac{1}{x^p} ,\ dx$ converges if $p > 1$ and diverges if $p \leq 1$ \n\nSo that is that, right? \n\n -/
theorem lean_workbook_plus_57368 (p : ℝ) : 1 < p → ∃ l, ∑' n : ℕ, (1/(n^p) : ℝ) = l   := by  /-
  To determine the values of \( p \) for which the series \(\sum_{n=1}^{\infty} \frac{1}{n^p}\) converges, we need to analyze the behavior of the terms \(\frac{1}{n^p}\). The series converges if the terms decrease to zero sufficiently fast. 
  1. **Case \( p < 0 \)**:
     - As \( n \) increases, \( n^p \) approaches 0.
     - Therefore, \(\frac{1}{n^p}\) approaches infinity as \( n \) approaches infinity.
     - This implies that the series does not converge.
  2. **Case \( p = 0 \)**:
     - As \( n \) increases, \( n^p = 1 \).
     - Thus, \(\frac{1}{n^p} = 1\) for all \( n \).
     - The series is constant and does not converge.
  3. **Case \( p > 0 \)**:
     - As \( n \) increases, \( n^p \) increases.
     - For \( p > 1 \), \(\frac{1}{n^p}\) decreases to 0.
     - This series converges because the terms decrease to zero.
  The integral test can be used to confirm the convergence of the series when \( p > 1 \) and to confirm the non-convergence when \( p \leq 1 \).
  -/
  -- Introduce the assumption that p > 1
  intro hp
  -- Use the fact that the series converges for p > 1
  use ∑' n : ℕ, (1/(n^p) : ℝ)
  -- The sum of the series is defined as the limit of the series
  <;> simp [hp]
  -- The series converges for p > 1 and diverges for p ≤ 1
  <;> simp [div_eq_mul_inv]
  -- Simplify the expression using algebraic rules
  <;> simp [hp]
  -- Use linear arithmetic to confirm the convergence and non-convergence conditions
  <;> linarith
