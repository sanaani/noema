import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that \n\n $$\sum\limits_{cyc}{\frac{a^3}{a^2+4b^2}} \ge \frac{1}{5}, \ a+b+c=1, \ a,b,c\in\mathbb{R^+}.$$ \n\n $\sum\frac{a^3}{a^2+4b^2}\geq\sum\frac{13a-8b}{25}\Longleftrightarrow\sum\frac{4(3a+8b)(a-b)^2}{25(a^2+4b^2)}\geq 0$ -/
theorem lean_workbook_plus_69123 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 1) : (a^3 / (a^2 + 4 * b^2) + b^3 / (b^2 + 4 * c^2) + c^3 / (c^2 + 4 * a^2)) ≥ 1 / 5   := by
  /-
  To prove the inequality \(\sum\limits_{cyc}{\frac{a^3}{a^2+4b^2}} \ge \frac{1}{5}\), where \(a + b + c = 1\) and \(a, b, c \in \mathbb{R}^+\), we can use the following steps:
  1. **Establish the inequality**: We need to show that \(\sum\frac{a^3}{a^2+4b^2} \geq \sum\frac{13a - 8b}{25}\).
  2. **Equivalent form**: This can be rewritten as \(\sum\frac{4(3a + 8b)(a - b)^2}{25(a^2 + 4b^2)} \geq 0\).
  3. **Non-negativity**: Since \(a, b, c > 0\) and \(a + b + c = 1\), the terms \(\frac{4(3a + 8b)(a - b)^2}{25(a^2 + 4b^2)}\) are non-negative due to the positivity of \(a, b, c\) and the structure of the inequality.
  -/
  have h₁ : a^3 / (a^2 + 4 * b^2) ≥ (13 * a - 8 * b) / 25 := by
    -- Use the division inequality to rewrite the term
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr _
    -- Use non-linear arithmetic to prove the inequality
    nlinarith [sq_nonneg (a - b), sq_nonneg (a + b), ha, hb]
  have h₂ : b^3 / (b^2 + 4 * c^2) ≥ (13 * b - 8 * c) / 25 := by
    -- Use the division inequality to rewrite the term
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr _
    -- Use non-linear arithmetic to prove the inequality
    nlinarith [sq_nonneg (b - c), sq_nonneg (b + c), hb, hc]
  have h₃ : c^3 / (c^2 + 4 * a^2) ≥ (13 * c - 8 * a) / 25 := by
    -- Use the division inequality to rewrite the term
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr _
    -- Use non-linear arithmetic to prove the inequality
    nlinarith [sq_nonneg (c - a), sq_nonneg (c + a), hc, ha]
  -- Sum the inequalities to get the final result
  nlinarith
