import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- answer is $x\in(-\infty, -5]\cup[3, \infty)$. -/
theorem lean_workbook_plus_1986 (x : ℝ) : (x ≤ -5 ∨ 3 ≤ x) ↔ x ∈ Set.Iic (-5) ∪ Set.Ici 3   := by
  /-
  The theorem states that for any real number \( x \), the condition \( x \leq -5 \) or \( 3 \leq x \) is equivalent to \( x \) belonging to the union of the intervals \( (-\infty, -5] \) and \( [3, \infty) \). The proof involves showing that each condition implies the other.
  1. **Forward Direction**: If \( x \leq -5 \) or \( 3 \leq x \), then \( x \) is in the union of \( (-\infty, -5] \) and \( [3, \infty) \).
  2. **Backward Direction**: If \( x \) is in the union of \( (-\infty, -5] \) and \( [3, \infty) \), then \( x \leq -5 \) or \( 3 \leq x \).
  -/
  -- We need to show that the condition (x ≤ -5 ∨ 3 ≤ x) is equivalent to x ∈ Set.Iic (-5) ∪ Set.Ici 3.
  constructor
  -- Forward direction: Assume (x ≤ -5 ∨ 3 ≤ x).
  intro h
  -- We need to show x ∈ Set.Iic (-5) ∪ Set.Ici 3.
  cases' h with h h
  -- Case 1: x ≤ -5
  left
  exact h
  -- Case 2: 3 ≤ x
  right
  exact h
  -- Backward direction: Assume x ∈ Set.Iic (-5) ∪ Set.Ici 3.
  intro h
  -- We need to show (x ≤ -5 ∨ 3 ≤ x).
  cases' h with h h
  -- Case 1: x ≤ -5
  left
  exact h
  -- Case 2: 3 ≤ x
  right
  exact h
