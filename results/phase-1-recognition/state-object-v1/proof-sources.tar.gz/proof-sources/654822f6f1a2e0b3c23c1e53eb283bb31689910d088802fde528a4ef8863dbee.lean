import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $(a+b)(b+c)(c+a)\geq 4(a+b-1)$ given $a, b, c>0$ and $abc=1$. -/
theorem lean_workbook_plus_27848 (a b c : ℝ) (habc : a * b * c = 1) (ha : a > 0) (hb : b > 0) (hc : c > 0) : (a + b) * (b + c) * (c + a) ≥ 4 * (a + b - 1)   := by
  /-
  Given \( a, b, c > 0 \) and \( abc = 1 \), we need to prove that \( (a+b)(b+c)(c+a) \geq 4(a+b-1) \).
  1. Start by expanding the left-hand side of the inequality.
  2. Use the fact that \( abc = 1 \) to simplify the expression.
  3. Apply the non-negativity of squares to derive the desired inequality.
  -/
  -- Expand the left-hand side of the inequality to facilitate comparison with the right-hand side.
  ring_nf
  -- Use non-negative arithmetic to derive the inequality.
  -- Specifically, use the fact that the square of any real number is non-negative.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_pos ha hb, mul_pos hb hc, mul_pos hc ha,
    sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1)]
