import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Find the value of $\frac{3}{8} \cdot \frac{5}{7}$ . -/
theorem lean_workbook_plus_74969 (a b c d : ℚ) (h₁ : a = 3 / 8) (h₂ : b = 5 / 7) : a * b = 15 / 56   := by
  /-
  To find the value of \(\frac{3}{8} \cdot \frac{5}{7}\), we start by substituting the given values for \(a\) and \(b\). We then simplify the expression by multiplying the numerators and the denominators. The result is \(\frac{15}{56}\).
  -/
  -- Substitute the given values for a and b.
  rw [h₁, h₂]
  -- Simplify the expression by multiplying the numerators and the denominators.
  norm_num
