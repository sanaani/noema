import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove $\cos A + \cos B = 2 \cos{\frac{A + B}{2}} \cos{\frac{A - B}{2}}$ -/
theorem lean_workbook_11296 (A B : ℝ) : cos A + cos B = 2 * cos ((A + B) / 2) * cos ((A - B) / 2)  := by
  /-
  To prove the identity \(\cos A + \cos B = 2 \cos{\frac{A + B}{2}} \cos{\frac{A - B}{2}}\), we start by expressing \(A\) and \(B\) in terms of their average and half the difference. Specifically, we have:
  \[ A = \frac{A + B}{2} + \frac{A - B}{2} \]
  \[ B = \frac{A + B}{2} - \frac{A - B}{2} \]
  Next, we substitute these expressions into the original identity. Using the known trigonometric identities for the cosine of a sum and a difference, we get:
  \[ \cos \left( \frac{A + B}{2} + \frac{A - B}{2} \right) = \cos \left( \frac{A + B}{2} \right) \cos \left( \frac{A - B}{2} \right) - \sin \left( \frac{A + B}{2} \right) \sin \left( \frac{A - B}{2} \right) \]
  \[ \cos \left( \frac{A + B}{2} - \frac{A - B}{2} \right) = \cos \left( \frac{A + B}{2} \right) \cos \left( \frac{A - B}{2} \right) + \sin \left( \frac{A + B}{2} \right) \sin \left( \frac{A - B}{2} \right) \]
  Adding these two equations, we obtain:
  \[ \cos \left( \frac{A + B}{2} + \frac{A - B}{2} \right) + \cos \left( \frac{A + B}{2} - \frac{A - B}{2} \right) = 2 \cos \left( \frac{A + B}{2} \right) \cos \left( \frac{A - B}{2} \right) \]
  Thus, we have shown that:
  \[ \cos A + \cos B = 2 \cos \left( \frac{A + B}{2} \right) \cos \left( \frac{A - B}{2} \right) \]
  -/
  have h₀ : A = (A + B) / 2 + (A - B) / 2 := by ring
  have h₁ : B = (A + B) / 2 - (A - B) / 2 := by ring
  rw [h₀, h₁]
  simp [cos_add, cos_sub]
  ring
