import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for all positive real numbers $x, y, z$ the following inequality holds:\n\n $\frac 1{x + y} + \frac 1{y + z} + \frac 1{z + x} \ge \frac {15 (x + y + z)}{2(x^2 + y^2 + z^2) + 8 (xy + yz + zx)}.$ -/
theorem lean_workbook_12680 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) : 1 / (x + y) + 1 / (y + z) + 1 / (z + x) ≥ 15 * (x + y + z) / (2 * (x ^ 2 + y ^ 2 + z ^ 2) + 8 * (x * y + y * z + z * x))  := by
  /-
  To prove the inequality \(\frac{1}{x + y} + \frac{1}{y + z} + \frac{1}{z + x} \ge \frac{15 (x + y + z)}{2(x^2 + y^2 + z^2) + 8 (xy + yz + zx)}\) for all positive real numbers \(x, y, z\), we start by simplifying the left-hand side using the common denominator \((x + y)(y + z)(z + x)\). We then compare this expression with the right-hand side, leveraging algebraic manipulations and inequalities to show that the left-hand side is indeed greater than or equal to the right-hand side.
  -/
  have h₀ : 0 < x + y + z := by linarith
  have h₁ : 0 < x * y := by positivity
  have h₂ : 0 < y * z := by positivity
  have h₃ : 0 < z * x := by positivity
  field_simp [h₀.ne', h₁.ne', h₂.ne', h₃.ne']
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    mul_self_nonneg (x + y + z), mul_self_nonneg (x - y + z),
    mul_self_nonneg (x + y - z), mul_self_nonneg (x - y - z)]
  all_goals positivity
