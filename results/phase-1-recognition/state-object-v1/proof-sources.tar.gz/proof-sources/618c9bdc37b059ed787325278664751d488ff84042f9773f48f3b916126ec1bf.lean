import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a, b, c >0$ . Prove that: $ \boxed{a^4+b^4+c^4\ge (a+b+c)abc}$ -/
theorem lean_workbook_18245 (a b c : ℝ) (ha : a>0) (hb : b>0) (hc : c>0) : a^4 + b^4 + c^4 >= (a + b + c) * a * b * c  := by
  /-
  We need to prove that for any positive real numbers \(a\), \(b\), and \(c\), the inequality \(a^4 + b^4 + c^4 \geq (a + b + c)abc\) holds. This can be shown using non-linear arithmetic by considering the non-negativity of various squared terms and their combinations.
  -/
  -- Use non-linear arithmetic to prove the inequality by considering the non-negativity of various squared terms and their combinations.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a^2 - b^2), sq_nonneg (b^2 - c^2), sq_nonneg (c^2 - a^2), sq_nonneg (a^2 + b^2), sq_nonneg (b^2 + c^2),
    sq_nonneg (c^2 + a^2), sq_nonneg (a^2 - a * b), sq_nonneg (b^2 - b * c), sq_nonneg (c^2 - c * a),
    sq_nonneg (a * b - b * c), sq_nonneg (b * c - c * a), sq_nonneg (c * a - a * b)]
