import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- With $a,b,c$ are real numbers satisfying relation \n $\begin{cases}a+b+c=6\ a^2+b^2+c^2=18\end{cases}$ \nProve that $a,b,c\in[0;4]$ -/
theorem lean_workbook_plus_3304 (a b c : ℝ) (h : a + b + c = 6 ∧ a ^ 2 + b ^ 2 + c ^ 2 = 18) : a ∈ Set.Icc 0 4 ∧ b ∈ Set.Icc 0 4 ∧ c ∈ Set.Icc 0 4   := by
  /-
  Given real numbers \(a\), \(b\), and \(c\) that satisfy the system of equations:
  \[
  \begin{cases}
  a + b + c = 6 \\
  a^2 + b^2 + c^2 = 18
  \end{cases}
  \]
  We need to prove that \(a, b, c \in [0; 4]\).
  First, we use the given equations to derive additional properties. By squaring the sum of the equations, we get:
  \[
  (a + b + c)^2 = 6^2 \implies a^2 + b^2 + c^2 + 2(ab + bc + ca) = 36
  \]
  Using the second equation \(a^2 + b^2 + c^2 = 18\), we substitute to find:
  \[
  18 + 2(ab + bc + ca) = 36 \implies 2(ab + bc + ca) = 18 \implies ab + bc + ca = 9
  \]
  Next, we use the non-negativity of squares to establish bounds on \(a\), \(b\), and \(c\). We know that:
  \[
  (a - b)^2 \geq 0, \quad (b - c)^2 \geq 0, \quad (c - a)^2 \geq 0
  \]
  These inequalities imply that \(a\), \(b\), and \(c\) are all within the interval \([0; 4]\).
  -/
  -- We need to prove that a, b, and c are in the interval [0; 4].
  refine' ⟨⟨_, _⟩, ⟨_, _⟩, ⟨_, _⟩⟩ <;>
    -- Use non-negativity of squares and algebraic properties to establish bounds.
    nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
