import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c>0$ and $a+b+c=a^3+b^3+c^3. $ Prove that\n\n $$ abc\leq 1$$ -/
theorem lean_workbook_14325 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = a^3 + b^3 + c^3) : a * b * c ≤ 1  := by
  /-
  Given \(a, b, c > 0\) and \(a + b + c = a^3 + b^3 + c^3\), we need to prove that \(abc \leq 1\).
  1. **Normalization and Simplification**: We start by normalizing the given equation \(a + b + c = a^3 + b^3 + c^3\).
  2. **Non-linear Arithmetic**: Using non-linear arithmetic, we derive inequalities that constrain the values of \(a, b,\) and \(c\).
  3. **Conclusion**: By combining these inequalities, we conclude that \(abc \leq 1\).
  -/
  -- Normalize the given equation and the goal to prepare for further simplification.
  ring_nf at habc ⊢
  -- Use non-linear arithmetic to derive inequalities that constrain the values of a, b, and c.
  -- Specifically, we use the fact that the square of any real number is non-negative to derive bounds.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
