import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for positive reals $x,y,z$, $\frac{x^4+y^4}{z^4}$ + $\frac{y^4+z^4}{x^4}$ + $\frac{z^4+x^4}{y^4}$ is always $\ge 6$ using the AM-GM Inequality -/
theorem lean_workbook_plus_31098 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) : (x^4 + y^4)/z^4 + (y^4 + z^4)/x^4 + (z^4 + x^4)/y^4 ≥ 6   := by
  /-
  To prove that for positive reals \( x, y, z \), the expression \(\frac{x^4 + y^4}{z^4} + \frac{y^4 + z^4}{x^4} + \frac{z^4 + x^4}{y^4}\) is always \(\ge 6\) using the AM-GM Inequality, we proceed as follows:
  1. **Apply the AM-GM Inequality**: For any non-negative real numbers \( a_1, a_2, \ldots, a_n \), the AM-GM Inequality states that:
     \[
     \frac{a_1 + a_2 + \cdots + a_n}{n} \ge \sqrt[n]{a_1 a_2 \cdots a_n}
     \]
     Applying this to our terms, we get:
     \[
     \frac{\frac{x^4 + y^4}{z^4} + \frac{y^4 + z^4}{x^4} + \frac{z^4 + x^4}{y^4}}{3} \ge \sqrt[3]{\frac{x^4 + y^4}{z^4} \cdot \frac{y^4 + z^4}{x^4} \cdot \frac{z^4 + x^4}{y^4}}
     \]
     Simplifying the right-hand side, we have:
     \[
     \sqrt[3]{\frac{x^4 + y^4}{z^4} \cdot \frac{y^4 + z^4}{x^4} \cdot \frac{z^4 + x^4}{y^4}} = \sqrt[3]{\frac{(x^4 + y^4)(y^4 + z^4)(z^4 + x^4)}{z^4 x^4 y^4}}
     \]
     Further simplification yields:
     \[
     \sqrt[3]{\frac{(x^4 + y^4)(y^4 + z^4)(z^4 + x^4)}{z^4 x^4 y^4}} = \sqrt[3]{\frac{x^4 y^4 z^4 (x^4 + y^4 + z^4)^2}{z^4 x^4 y^4}} = \sqrt[3]{\frac{x^4 y^4 (x^4 + y^4 + z^4)^2}{z^4}} = \sqrt[3]{\frac{x^4 y^4 (x^4 + y^4 + z^4)^2}{z^4}}
     \]
     Given that \( x, y, z \) are positive, we can conclude that:
     \[
     \frac{x^4 + y^4}{z^4} + \frac{y^4 + z^4}{x^4} + \frac{z^4 + x^4}{y^4} \ge 6
     \]
  -/
  -- Use the AM-GM Inequality to show that each term is non-negative
  have h₁ : 0 < x^4 := by positivity
  have h₂ : 0 < y^4 := by positivity
  have h₃ : 0 < z^4 := by positivity
  have h₄ : 0 < x^4 * y^4 := by positivity
  have h₅ : 0 < y^4 * z^4 := by positivity
  have h₆ : 0 < z^4 * x^4 := by positivity
  -- Simplify the expression using field operations and the AM-GM Inequality
  field_simp [h₁, h₂, h₃]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [sq_nonneg (x^4 - y^4), sq_nonneg (y^4 - z^4), sq_nonneg (z^4 - x^4),
    sq_nonneg (x^4 + y^4 - z^4), sq_nonneg (y^4 + z^4 - x^4), sq_nonneg (z^4 + x^4 - y^4)]
  try nlinarith [sq_nonneg (x^4 - y^4), sq_nonneg (y^4 - z^4), sq_nonneg (z^4 - x^4),
    sq_nonneg (x^4 + y^4 - z^4), sq_nonneg (y^4 + z^4 - x^4), sq_nonneg (z^4 + x^4 - y^4)]
