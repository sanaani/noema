import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a, b, c > -2$ and $a+3b+5c \leq 1$. Prove that $\frac{1}{a+2}+\frac{3}{b+4}+\frac{5}{c+6} \geq \frac{9}{5}$. -/
theorem lean_workbook_plus_35434 (a b c : ℝ) (ha : -2 < a) (hb : -2 < b) (hc : -2 < c) (habc : a + 3 * b + 5 * c ≤ 1) : 1 / (a + 2) + 3 / (b + 4) + 5 / (c + 6) ≥ 9 / 5   := by
  /-
  Given \( a, b, c > -2 \) and \( a + 3b + 5c \leq 1 \), we need to prove that:
  \[
  \frac{1}{a+2} + \frac{3}{b+4} + \frac{5}{c+6} \geq \frac{9}{5}
  \]
  First, we establish that \( a + 2 > 0 \), \( b + 4 > 0 \), and \( c + 6 > 0 \) because \( a, b, c > -2 \).
  Next, we simplify the inequality by clearing the denominators using the fact that \( a + 2 \), \( b + 4 \), and \( c + 6 \) are positive. This allows us to rewrite the inequality in a form that can be handled by linear arithmetic.
  Finally, we use linear arithmetic to verify that the simplified inequality holds given the constraints \( a, b, c > -2 \) and \( a + 3b + 5c \leq 1 \).
  -/
  -- Establish that a + 2 > 0, b + 4 > 0, and c + 6 > 0 because a, b, c > -2.
  have h₁ : a + 2 > 0 := by linarith
  have h₂ : b + 4 > 0 := by linarith
  have h₃ : c + 6 > 0 := by linarith
  -- Clear the denominators by multiplying through by (a + 2)(b + 4)(c + 6).
  field_simp [h₁, h₂, h₃]
  -- Rewrite the inequality in a form suitable for linear arithmetic.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [mul_pos h₁ h₂, mul_pos h₁ h₃, mul_pos h₂ h₃,
    mul_self_nonneg (a + 2 - b - 4), mul_self_nonneg (b + 4 - c - 6),
    mul_self_nonneg (c + 6 - a - 2)]
