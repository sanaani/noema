import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- prove that $ x^4 + y^4 + z^4 + xy^3 + yz^3 + zx^3 \ge\ 2(yx^3 + zy^3 + xz^3)$ -/
theorem lean_workbook_7742 (x y z : ℝ) : x ^ 4 + y ^ 4 + z ^ 4 + x * y ^ 3 + y * z ^ 3 + z * x ^ 3 ≥ 2 * (x * y ^ 3 + y * z ^ 3 + z * x ^ 3)  := by
  /-
  To prove the inequality \( x^4 + y^4 + z^4 + xy^3 + yz^3 + zx^3 \ge 2(xy^3 + yz^3 + zx^3) \), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the result by considering the non-negativity of squares. Specifically, we will use the fact that the square of any real number is non-negative to establish the desired inequality.
  -/
  -- Use the nlinarith tactic to prove the inequality.
  -- The nlinarith tactic will consider the non-negativity of squares and other polynomial expressions to deduce the result.
  nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    sq_nonneg (x + y), sq_nonneg (y + z), sq_nonneg (z + x),
    sq_nonneg (x ^ 2 - y ^ 2), sq_nonneg (y ^ 2 - z ^ 2), sq_nonneg (z ^ 2 - x ^ 2),
    sq_nonneg (x ^ 2 + y ^ 2), sq_nonneg (y ^ 2 + z ^ 2), sq_nonneg (z ^ 2 + x ^ 2)]
