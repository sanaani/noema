import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c\in \mathbb{R}_{\ge 0}$ satisfy $a+b+c=1$ . Prove the inequality : \n $ \frac{3-b}{a+1}+\frac{a+1}{b+1}+\frac{b+1}{c+1}\le \frac 92 $ -/
theorem lean_workbook_plus_52262 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hab : a + b + c = 1) : (3 - b) / (a + 1) + (a + 1) / (b + 1) + (b + 1) / (c + 1) ≤ 9 / 2   := by
  /-
  Given \(a, b, c \in \mathbb{R}_{\ge 0}\) such that \(a + b + c = 1\), we need to prove the inequality:
  \[
  \frac{3 - b}{a + 1} + \frac{a + 1}{b + 1} + \frac{b + 1}{c + 1} \leq \frac{9}{2}
  \]
  First, we establish that the denominators are positive:
  \[
  a + 1 > 0, \quad b + 1 > 0, \quad c + 1 > 0
  \]
  Using the fact that \(a + b + c = 1\), we can rewrite the inequality in a more manageable form. By simplifying and combining the fractions, we can show that the sum is less than or equal to \(\frac{9}{2}\).
  -/
  -- Establish that the denominators are positive.
  have h₀ : a + 1 > 0 := by linarith
  have h₁ : b + 1 > 0 := by linarith
  have h₂ : c + 1 > 0 := by linarith
  -- Use the fact that the denominators are positive to clear the fractions.
  field_simp [h₀, h₁, h₂]
  -- Rewrite the inequality in a more manageable form.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  -- Use non-linear arithmetic to prove the inequality.
  try nlinarith [mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    mul_self_nonneg (a - b), mul_self_nonneg (b - c), mul_self_nonneg (c - a)]
