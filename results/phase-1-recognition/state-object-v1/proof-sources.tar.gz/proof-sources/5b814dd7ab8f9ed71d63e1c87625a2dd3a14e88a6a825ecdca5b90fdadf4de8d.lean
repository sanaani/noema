import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a, b$ be the positive real numbers such that $\frac{1}{a}+\frac{a}{b}=4 .$ Prove that $$ a+\frac{b}{a}\geq 1$$ -/
theorem lean_workbook_21633 (a b : ℝ) (ha : 0 < a) (hb : 0 < b) : 1 / a + a / b = 4 → a + b / a ≥ 1  := by
  /-
  Given positive real numbers \(a\) and \(b\) such that \(\frac{1}{a} + \frac{a}{b} = 4\), we need to prove that \(a + \frac{b}{a} \geq 1\).
  1. Start by assuming the given equation \(\frac{1}{a} + \frac{a}{b} = 4\).
  2. Simplify the equation using field operations to clear the denominators.
  3. Use the non-negativity of squares to derive inequalities that can be combined to show the desired result.
  -/
  intro h -- Assume the given equation holds
  field_simp at h ⊢ -- Simplify the equation and the goal using field operations
  rw [le_div_iff₀ ha] -- Rewrite the inequality using the division by a positive number
  nlinarith [sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2)] -- Use the non-negativity of squares to derive the desired inequality
