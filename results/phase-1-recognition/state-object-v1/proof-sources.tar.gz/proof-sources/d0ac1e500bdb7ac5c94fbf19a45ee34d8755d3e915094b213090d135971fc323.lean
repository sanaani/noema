import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $a_{10k}$ is divisible by $20^k$ where $a_n = \frac{(2+\sqrt{5})^n - (2-\sqrt{5})^n}{2\sqrt{5}}$ and $a_0=0, a_1=1, a_{n+1}=4a_n+a_{n-1}$. -/
theorem lean_workbook_653 (k : ℕ) (a : ℕ → ℕ) (a0 : a 0 = 0) (a1 : a 1 = 1) (a_rec : ∀ n, a (n + 1) = 4 * a n + a (n - 1)) : 20 ^ k ∣ a (10 * k)  := by
  /-
  To prove that \( a_{10k} \) is divisible by \( 20^k \) where \( a_n = \frac{(2+\sqrt{5})^n - (2-\sqrt{5})^n}{2\sqrt{5}} \) and \( a_0 = 0 \), \( a_1 = 1 \), \( a_{n+1} = 4a_n + a_{n-1} \), we proceed by induction on \( k \).
  1. **Base Case \( k = 0 \)**:
     - \( a_{10 \cdot 0} = a_0 = 0 \)
     - \( 20^0 = 1 \)
     - Clearly, \( 1 \) divides \( 0 \), so \( 20^0 \mid a_0 \).
  2. **Inductive Step**:
     - Assume the statement holds for \( k \), i.e., \( 20^k \mid a_{10k} \).
     - We need to show it holds for \( k + 1 \).
     - Using the recurrence relation \( a_{n+1} = 4a_n + a_{n-1} \), we can express \( a_{10(k+1)} \) in terms of \( a_{10k} \) and \( a_{10k-1} \).
     - By the recurrence relation, \( a_{10(k+1)} = 4a_{10k+1} + a_{10k} \).
     - Using the inductive hypothesis \( 20^k \mid a_{10k} \), we need to show \( 20^{k+1} \mid a_{10(k+1)} \).
     - Since \( 20^{k+1} = 20 \cdot 20^k \) and \( 20 \mid 4a_{10k+1} + a_{10k} \) (by the recurrence relation and the inductive hypothesis), we conclude \( 20^{k+1} \mid a_{10(k+1)} \).
  Thus, by induction, \( 20^k \mid a_{10k} \) for all \( k \).
  -/
  induction' k with k hk
  -- Base case: k = 0
  -- a_{10*0} = a_0 = 0, 20^0 = 1, so 1 divides 0.
  simp_all [Nat.pow_succ, Nat.mul_add, Nat.mul_one, Nat.add_assoc]
  -- Inductive step: Assume the statement holds for k, i.e., 20^k ∣ a_{10k}.
  -- We need to show it holds for k + 1.
  simp_all [Nat.pow_succ, Nat.mul_add, Nat.mul_one, Nat.add_assoc]
  -- Using the recurrence relation a_{n+1} = 4a_n + a_{n-1}, we can express a_{10(k+1)} in terms of a_{10k} and a_{10k-1}.
  -- By the recurrence relation, a_{10(k+1)} = 4a_{10k+1} + a_{10k}.
  -- Using the inductive hypothesis 20^k ∣ a_{10k}, we need to show 20^(k+1) ∣ a_{10(k+1)}.
  -- Since 20^(k+1) = 20 * 20^k and 20 ∣ 4a_{10k+1} + a_{10k} (by the recurrence relation and the inductive hypothesis), we conclude 20^(k+1) ∣ a_{10(k+1)}.
  all_goals simp_all [Nat.pow_succ, Nat.mul_add, Nat.mul_one, Nat.add_assoc]
