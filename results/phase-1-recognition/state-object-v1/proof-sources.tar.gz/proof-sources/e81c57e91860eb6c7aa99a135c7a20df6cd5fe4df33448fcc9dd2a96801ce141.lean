import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a$ , $b$ and $c$ be positive numbers such that $a^2+b^2+c^2+abc=4$ . Prove that: $\frac{bc}{a}+\frac{ac}{b}+\frac{ab}{c}\leq \frac{4}{abc}-1$ -/
theorem lean_workbook_plus_28686 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) : a^2 + b^2 + c^2 + a * b * c = 4 → b * c / a + a * c / b + a * b / c ≤ 4 / a / b / c - 1   := by
  /-
  Given positive numbers \(a\), \(b\), and \(c\) such that \(a^2 + b^2 + c^2 + abc = 4\), we need to prove that:
  \[
  \frac{bc}{a} + \frac{ac}{b} + \frac{ab}{c} \leq \frac{4}{abc} - 1
  \]
  Since \(a\), \(b\), and \(c\) are positive and \(abc = 1\), we can simplify the inequality to:
  \[
  \frac{bc}{a} + \frac{ac}{b} + \frac{ab}{c} \leq 4 - 1 = 3
  \]
  To prove this, we start by considering the given condition \(a^2 + b^2 + c^2 + abc = 4\). We can use algebraic manipulation and inequalities to show that the left-hand side is bounded by the right-hand side. Specifically, we can use the fact that \(a\), \(b\), and \(c\) are positive and their squares sum up to 4, which implies that each term \(\frac{bc}{a}\), \(\frac{ac}{b}\), and \(\frac{ab}{c}\) is less than or equal to 1. Summing these terms, we get:
  \[
  \frac{bc}{a} + \frac{ac}{b} + \frac{ab}{c} \leq 3
  \]
  Thus, the inequality holds.
  -/
  intro h
  -- Simplify the inequality using the fact that a * b * c = 1
  field_simp [habc, mul_comm, mul_left_comm, mul_assoc]
  -- Use non-linear arithmetic to prove the inequality
  nlinarith [sq_nonneg (a + b + c), h, sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
