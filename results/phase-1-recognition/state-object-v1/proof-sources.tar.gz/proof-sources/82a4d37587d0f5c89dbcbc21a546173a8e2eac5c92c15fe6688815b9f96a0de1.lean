import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/-  $n^{3}-n=n(n^{2}-1)=(n-1)n(n+1)$ . If $n\equiv0\pmod3$ , $(n-1)n(n+1)\equiv-1\cdot0\cdot1=0\pmod3$ . If $n\equiv1\pmod3$ , $(n-1)n(n+1)\equiv0\cdot1\cdot2=0\pmod3$ . If $n\equiv2\pmod3$ , $(n-1)n(n+1)\equiv1\cdot2\cdot3=6\equiv0\pmod3$ . Therefore, $n^{3}-n$ always is divisible by 3. -/
theorem lean_workbook_51915 : ∀ n : ℕ, 3 ∣ n^3 - n  := by
  /-
  We need to show that for any natural number \( n \), \( n^3 - n \) is divisible by 3. We start by expressing \( n^3 - n \) in a factored form:
  \[ n^3 - n = n(n^2 - 1) = n(n - 1)(n + 1) \]
  Next, we consider the possible remainders of \( n \) when divided by 3. These remainders can be 0, 1, or 2. We analyze each case:
  1. If \( n \equiv 0 \pmod{3} \), then \( n - 1 \equiv -1 \pmod{3} \) and \( n + 1 \equiv 2 \pmod{3} \), so:
     \[ (n - 1)n(n + 1) \equiv (-1) \cdot 0 \cdot 2 = 0 \pmod{3} \]
  2. If \( n \equiv 1 \pmod{3} \), then \( n - 1 \equiv 0 \pmod{3} \) and \( n + 1 \equiv 2 \pmod{3} \), so:
     \[ (n - 1)n(n + 1) \equiv 0 \cdot 1 \cdot 2 = 0 \pmod{3} \]
  3. If \( n \equiv 2 \pmod{3} \), then \( n - 1 \equiv 1 \pmod{3} \) and \( n + 1 \equiv 2 \pmod{3} \), so:
     \[ (n - 1)n(n + 1) \equiv 1 \cdot 2 \cdot 3 = 6 \equiv 0 \pmod{3} \]
  In all cases, \( (n - 1)n(n + 1) \) is divisible by 3, hence \( n^3 - n \) is divisible by 3.
  -/
  intro n
  have h₀ : n^3 % 3 = n % 3 := by
    -- We need to show that n^3 % 3 = n % 3 for any natural number n.
    -- We consider the possible remainders of n when divided by 3.
    have h₀ : n % 3 = 0 ∨ n % 3 = 1 ∨ n % 3 = 2 := by omega
    -- We analyze each case:
    rcases h₀ with (h₀ | h₀ | h₀) <;> simp [h₀, Nat.pow_succ, Nat.mul_mod, Nat.add_mod, Nat.mod_eq_of_lt]
  -- Using the above results, we conclude that n^3 - n is divisible by 3.
  omega
