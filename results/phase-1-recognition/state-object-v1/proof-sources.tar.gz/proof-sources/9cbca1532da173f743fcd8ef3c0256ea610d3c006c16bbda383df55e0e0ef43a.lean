import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c,d$ are nonnegative real numbers, then $(a + b + c + d)^{3}\\geq 4[a(c + d)^{2} + b(d + a)^{2} + c(a + b)^{2} + d(b + c)^{2}]$ -/
theorem lean_workbook_plus_279 (a b c d : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) : (a + b + c + d) ^ 3 ≥ 4 * (a * (c + d) ^ 2 + b * (d + a) ^ 2 + c * (a + b) ^ 2 + d * (b + c) ^ 2)   := by
  /-
  We need to show that for nonnegative real numbers \(a, b, c, d\), the inequality \((a + b + c + d)^3 \geq 4[a(c + d)^2 + b(d + a)^2 + c(a + b)^2 + d(b + c)^2]\) holds. This can be proven using non-linear arithmetic (nlinarith) which checks the inequality by applying a series of algebraic manipulations and ensuring the result is non-negative.
  -/
  -- Use non-linear arithmetic to check the inequality by applying a series of algebraic manipulations and ensuring the result is non-negative.
  nlinarith [sq_nonneg (a + b + c + d), sq_nonneg (a - b + c - d), sq_nonneg (a + b - c - d), sq_nonneg (a - b - c + d), sq_nonneg (a + c - b), sq_nonneg (a - c + b), sq_nonneg (a + d - c), sq_nonneg (a - d + c), sq_nonneg (b + c - d), sq_nonneg (b - c + d), sq_nonneg (b + d - c), sq_nonneg (b - d + c), sq_nonneg (c + d - a), sq_nonneg (c - d + a), sq_nonneg (c + a - d), sq_nonneg (c - a + d), sq_nonneg (d + a - b), sq_nonneg (d - a + b), sq_nonneg (d + b - a), sq_nonneg (d - b + a), sq_nonneg (d + c - a), sq_nonneg (d - c + a), sq_nonneg (d - b), sq_nonneg (b - a), sq_nonneg (a - b), sq_nonneg (c - d), sq_nonneg (d - c)]
