import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let a,b,c>0 Prove that: \n $ \frac {{a^3 + b^3 + c^3 }}{{abc}} + 9\frac {{ab + bc + ac}}{{a^2 + b^2 + c^2 }} \ge 12$ \nI know it's easy but It is nice. \nThank you, my dear friend for the nice ineq. \nAnd by Am-Gm, we have the similar result: \nWith $ a, b, c > 0$ and $ k \geq\ 1$ :\n $ \sqrt[k]{\frac{a^3+b^3+c^3}{abc}} + 3. \sqrt[k]{\frac{ab+bc+ca}{a^2+b^2+c^2}} \geq\ 3 + \sqrt[k]{3}$ \nBecause of your ineq and: $ (a^3+b^3+c^3)(ab+bc+ca) \geq\ 3abc(a^2+b^2+c^2)$ -/
theorem lean_workbook_18711 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : (a^3 + b^3 + c^3) / (a * b * c) + 9 * (a * b + b * c + c * a) / (a^2 + b^2 + c^2) ≥ 12  := by
  /-
  We need to prove that for positive real numbers \(a\), \(b\), and \(c\), the inequality 
  \[
  \frac{a^3 + b^3 + c^3}{abc} + 9 \frac{ab + bc + ac}{a^2 + b^2 + c^2} \geq 12
  \]
  holds. This is a nice inequality, and it can be derived using the Arithmetic Mean-Geometric Mean (AM-GM) inequality. Specifically, we can use the fact that for any non-negative real numbers \(x_1, x_2, \ldots, x_n\),
  \[
  \frac{x_1 + x_2 + \cdots + x_n}{n} \geq \sqrt[n]{x_1 x_2 \cdots x_n}
  \]
  and
  \[
  \sqrt[n]{x_1 x_2 \cdots x_n} \geq \sqrt[n]{n \left( \frac{x_1 + x_2 + \cdots + x_n}{n} \right)^n} = 1
  \]
  Combining these, we get:
  \[
  \frac{x_1 + x_2 + \cdots + x_n}{n} + \sqrt[n]{x_1 x_2 \cdots x_n} \geq 1
  \]
  Applying this to our terms, we have:
  \[
  \frac{a^3 + b^3 + c^3}{abc} + \sqrt[3]{a^3 b^3 c^3} \geq 1
  \]
  and
  \[
  \frac{ab + bc + ac}{a^2 + b^2 + c^2} + \sqrt[3]{(ab)(bc)(ac)} \geq 1
  \]
  Combining these, we get:
  \[
  \frac{a^3 + b^3 + c^3}{abc} + 9 \frac{ab + bc + ac}{a^2 + b^2 + c^2} \geq 12
  \]
  -/
  have h₁ : 0 < a * b * c := by positivity
  have h₂ : 0 < a * b := by positivity
  have h₃ : 0 < b * c := by positivity
  have h₄ : 0 < c * a := by positivity
  field_simp [h₁, h₂, h₃, h₄]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_nonneg (sq_nonneg (a - b)) (sq_nonneg (b - c)), mul_nonneg (sq_nonneg (b - c)) (sq_nonneg (c - a)), mul_nonneg (sq_nonneg (c - a)) (sq_nonneg (a - b))]
  try positivity
