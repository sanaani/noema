import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c$ be real numbers. Prove that \n $$a^2+b^2+c^2+ka+\frac{k^2}{3}\ge ab+bc+ca+kc$$ Where $ k\in R.$ -/
theorem lean_workbook_plus_8931 (a b c k : ℝ): a^2 + b^2 + c^2 + k*a + k^2 / 3 ≥ a * b + b * c + c * a + k * c   := by
  /-
  To prove the inequality \( a^2 + b^2 + c^2 + ka + \frac{k^2}{3} \ge ab + bc + ca + kc \) for real numbers \( a, b, c, k \), we use the non-linear arithmetic (nlinarith) tactic. This tactic is designed to handle inequalities involving squares and linear combinations of terms. Specifically, we consider the squares of the differences \( (a - b + k/3) \), \( (b - c + k/3) \), \( (c - a + k/3) \), and \( (a + b + c - k) \). By ensuring that these squares are non-negative, we can establish the desired inequality.
  -/
  -- Use the non-linear arithmetic tactic to prove the inequality.
  -- This tactic will consider the non-negativity of squares and other algebraic properties to establish the inequality.
  nlinarith [sq_nonneg (a - b + k / 3), sq_nonneg (b - c + k / 3), sq_nonneg (c - a + k / 3),
    sq_nonneg (a + b + c - k), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b + c), sq_nonneg (a + b + c - k), sq_nonneg (a + b + c + k),
    sq_nonneg (a + b + c + k / 3), sq_nonneg (a - b + k / 3), sq_nonneg (b - c + k / 3),
    sq_nonneg (c - a + k / 3)]
