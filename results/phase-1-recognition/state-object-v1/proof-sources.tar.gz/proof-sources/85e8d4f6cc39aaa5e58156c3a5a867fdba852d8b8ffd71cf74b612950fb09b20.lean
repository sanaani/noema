import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- prove that \n $3(a^2b+ab^2+b^2c+bc^2+c^2a+ca^2)^2\le 4(a^2+b^2+c^2)^3$ -/
theorem lean_workbook_plus_14571 (a b c : ℝ) :
  3 * (a^2 * b + a * b^2 + b^2 * c + b * c^2 + c^2 * a + c * a^2)^2 ≤
  4 * (a^2 + b^2 + c^2)^3   := by
  /-
  We need to prove that for real numbers \(a\), \(b\), and \(c\), the inequality \(3(a^2b + ab^2 + b^2c + bc^2 + c^2a + ca^2)^2 \leq 4(a^2 + b^2 + c^2)^3\) holds. This can be shown using non-linear arithmetic by considering the non-negativity of squares and the properties of real numbers. Specifically, we will use the fact that the square of any real number is non-negative, and the product of non-negative numbers is also non-negative.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We provide specific non-negative terms to help the arithmetic solver.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_self_nonneg (a^2 - b^2),
    mul_self_nonneg (b^2 - c^2), mul_self_nonneg (c^2 - a^2), mul_self_nonneg (a * b - b * c),
    mul_self_nonneg (b * c - c * a), mul_self_nonneg (c * a - a * b)]
