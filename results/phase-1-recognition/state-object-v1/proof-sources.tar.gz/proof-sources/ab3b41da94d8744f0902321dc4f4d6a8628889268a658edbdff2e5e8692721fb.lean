import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c >0 $ such that $abc=1 $ .Prove that $ \frac{a}{a^{2}+a+1}+\frac{b}{b^{2}+b+1}+\frac{c}{c^{2}+c+1}\leq 1$ -/
theorem lean_workbook_36979 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) : a / (a ^ 2 + a + 1) + b / (b ^ 2 + b + 1) + c / (c ^ 2 + c + 1) ≤ 1  := by
  /-
  Given \(a, b, c > 0\) such that \(abc = 1\), we need to prove that:
  \[
  \frac{a}{a^2 + a + 1} + \frac{b}{b^2 + b + 1} + \frac{c}{c^2 + c + 1} \leq 1
  \]
  To prove this, we will use the fact that each term \(\frac{a}{a^2 + a + 1}\), \(\frac{b}{b^2 + b + 1}\), and \(\frac{c}{c^2 + c + 1}\) is less than or equal to \(\frac{1}{3}\). This can be shown by considering the inequality derived from the fact that \(a, b, c > 0\) and \(abc = 1\).
  -/
  -- We will show that each term is less than or equal to 1/3.
  have h₀ : a / (a ^ 2 + a + 1) ≤ 1 / 3 := by
    -- Use the division inequality to show that a / (a^2 + a + 1) ≤ 1/3.
    rw [div_le_iff₀ (show (0 : ℝ) < a ^ 2 + a + 1 by nlinarith)]
    nlinarith [sq_nonneg (a - 1), sq_nonneg (a - 1 / 2)]
  have h₁ : b / (b ^ 2 + b + 1) ≤ 1 / 3 := by
    -- Use the division inequality to show that b / (b^2 + b + 1) ≤ 1/3.
    rw [div_le_iff₀ (show (0 : ℝ) < b ^ 2 + b + 1 by nlinarith)]
    nlinarith [sq_nonneg (b - 1), sq_nonneg (b - 1 / 2)]
  have h₂ : c / (c ^ 2 + c + 1) ≤ 1 / 3 := by
    -- Use the division inequality to show that c / (c^2 + c + 1) ≤ 1/3.
    rw [div_le_iff₀ (show (0 : ℝ) < c ^ 2 + c + 1 by nlinarith)]
    nlinarith [sq_nonneg (c - 1), sq_nonneg (c - 1 / 2)]
  -- Sum the inequalities to get the final result.
  linarith
