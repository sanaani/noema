import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a, b, c >0$ such as $ a+b+c =3 $ . Prove that: \n $\sqrt{a}+\sqrt{b}+\sqrt{b}\geq ab+bc+ca$ -/
theorem lean_workbook_34313 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 3) :  Real.sqrt a + Real.sqrt b + Real.sqrt c ≥ a * b + b * c + c * a   := by
  /-
  Given \(a, b, c > 0\) such that \(a + b + c = 3\), we need to prove that:
  \[
  \sqrt{a} + \sqrt{b} + \sqrt{c} \geq ab + bc + ca
  \]
  To prove this, we will use the fact that the square root function is non-negative and apply basic algebraic inequalities. Specifically, we will use the non-negativity of the square root function and the given conditions to derive the desired inequality.
  -/
  have h₀ : 0 ≤ Real.sqrt a := Real.sqrt_nonneg a
  have h₁ : 0 ≤ Real.sqrt b := Real.sqrt_nonneg b
  have h₂ : 0 ≤ Real.sqrt c := Real.sqrt_nonneg c
  nlinarith [sq_sqrt (le_of_lt ha), sq_sqrt (le_of_lt hb), sq_sqrt (le_of_lt hc),
    sq_nonneg (Real.sqrt a - 1), sq_nonneg (Real.sqrt b - 1), sq_nonneg (Real.sqrt c - 1)]
