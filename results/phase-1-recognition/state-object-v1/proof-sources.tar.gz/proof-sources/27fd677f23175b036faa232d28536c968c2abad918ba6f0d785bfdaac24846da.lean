import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b>0.$ Prove that $\frac{a^2}{b}+\frac{b^2}{2a+b}\geq \frac{a+b}{2}$ -/
theorem lean_workbook_56422 (a b : ℝ) (ha : 0 < a) (hb : 0 < b) : a^2 / b + b^2 / (2 * a + b) ≥ (a + b) / 2  := by
  /-
  We need to prove that for positive real numbers \(a\) and \(b\), the inequality \(\frac{a^2}{b} + \frac{b^2}{2a + b} \geq \frac{a + b}{2}\) holds. To do this, we first establish that \(a\) and \(b\) are positive. We then simplify the expression using algebraic manipulations and finally use non-linear arithmetic to verify the inequality.
  -/
  -- Establish that a and b are positive.
  have h₁ : 0 < a := ha
  have h₂ : 0 < b := hb
  -- Simplify the expression using field operations and algebraic manipulations.
  field_simp [h₁.ne', h₂.ne', add_comm]
  -- Use non-linear arithmetic to verify the inequality.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [sq_nonneg (a - b), sq_nonneg (a - b + a), sq_nonneg (a - b - a)]
