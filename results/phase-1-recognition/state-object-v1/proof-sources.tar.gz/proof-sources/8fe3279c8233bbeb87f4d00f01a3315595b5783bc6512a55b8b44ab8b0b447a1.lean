import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- prove that \((a+bp)^2 + (b+cp)^2 + (c+ap)^2\ge \frac{(1+p)^2}{2}(a^2+b^2+c^2+ab+bc+ca)\) for \(a,b,c,p\ge 0\) -/
theorem lean_workbook_plus_8986 (a b c p : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) (hp : p ≥ 0) : (a + b * p) ^ 2 + (b + c * p) ^ 2 + (c + a * p) ^ 2 ≥ (1 + p) ^ 2 / 2 * (a ^ 2 + b ^ 2 + c ^ 2 + a * b + b * c + c * a)   := by
  /-
  To prove the inequality \((a + bp)^2 + (b + cp)^2 + (c + ap)^2 \ge \frac{(1 + p)^2}{2}(a^2 + b^2 + c^2 + ab + bc + ca)\) for \(a, b, c, p \ge 0\), we use the `nlinarith` tactic, which stands for "nonlinear arithmetic." This tactic is designed to handle inequalities involving polynomials and can automatically deduce the desired inequality by leveraging non-negative properties of squares and the given non-negativity of the variables.
  -/
  -- Use the `nlinarith` tactic to handle the inequality. This tactic will automatically apply known inequalities and properties of non-negative numbers to prove the desired inequality.
  nlinarith [sq_nonneg (a + b * p - (1 + p) * (a + b) / 2), sq_nonneg (b + c * p - (1 + p) * (b + c) / 2), sq_nonneg (c + a * p - (1 + p) * (c + a) / 2),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (p - 1)]
