import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that: \n $ x,y,z>0\Rightarrow (x+y+z)(\frac{1}{x}+\frac{1}{y}+\frac{1}{z})\ge 7+\frac{2(x^2+y^2+z^2)}{xy+yz+zx} $ \n -/
theorem lean_workbook_plus_39182 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) : (x + y + z) * (1 / x + 1 / y + 1 / z) ≥ 7 + 2 * (x ^ 2 + y ^ 2 + z ^ 2) / (x * y + y * z + z * x)   := by
  /-
  To prove the inequality \((x + y + z)\left(\frac{1}{x} + \frac{1}{y} + \frac{1}{z}\right) \ge 7 + \frac{2(x^2 + y^2 + z^2)}{xy + yz + zx}\) for \(x, y, z > 0\), we proceed as follows:
  1. **Simplify the expression**: Start by simplifying the left-hand side and the right-hand side of the inequality.
  2. **Clear denominators**: Multiply both sides by \(x \cdot y \cdot z\) to clear the denominators.
  3. **Expand and simplify**: Expand the left-hand side and simplify the right-hand side.
  4. **Apply non-negativity**: Use the fact that the square of any real number is non-negative to establish the inequality.
  -/
  have h₀ : 0 < x * y := by positivity
  have h₁ : 0 < y * z := by positivity
  have h₂ : 0 < z * x := by positivity
  field_simp [hx, hy, hz, h₀, h₁, h₂]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    sq_nonneg (x + y + z), sq_nonneg (x * y + y * z + z * x),
    sq_nonneg (x * y - y * z), sq_nonneg (y * z - z * x), sq_nonneg (z * x - x * y)]
