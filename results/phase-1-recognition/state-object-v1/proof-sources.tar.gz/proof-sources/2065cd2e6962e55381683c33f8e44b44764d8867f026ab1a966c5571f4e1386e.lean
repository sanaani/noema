import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $p\ge 5$ be a prime. Show that $4|p+1$ or $4|p-1$. -/
theorem lean_workbook_plus_8638 (p : ℕ) (h : p.Prime) (h5 : p ≥ 5) : 4 ∣ p + 1 ∨ 4 ∣ p - 1   := by
  /-
  Given a prime number \( p \) such that \( p \geq 5 \), we need to show that \( 4 \) divides \( p + 1 \) or \( 4 \) divides \( p - 1 \).
  1. **Case Analysis on \( p \mod 4 \)**:
     - Since \( p \) is a prime number and \( p \geq 5 \), we can consider the possible remainders of \( p \) when divided by 4. These remainders can only be 1 or 3.
     - If \( p \equiv 1 \mod 4 \), then \( p + 1 \equiv 2 \mod 4 \), and since 2 is not divisible by 4, we need to show that \( p - 1 \equiv 0 \mod 4 \).
     - If \( p \equiv 3 \mod 4 \), then \( p - 1 \equiv 2 \mod 4 \), and since 2 is not divisible by 4, we need to show that \( p + 1 \equiv 0 \mod 4 \).
  2. **Verification**:
     - If \( p \equiv 1 \mod 4 \), then \( p = 4k + 1 \) for some integer \( k \), and \( p - 1 = 4k \), which is divisible by 4.
     - If \( p \equiv 3 \mod 4 \), then \( p = 4k + 3 \) for some integer \( k \), and \( p + 1 = 4k + 4 \), which is divisible by 4.
  Thus, in both cases, we have shown that either \( 4 \) divides \( p + 1 \) or \( 4 \) divides \( p - 1 \).
  -/
  -- We need to show that 4 divides p + 1 or 4 divides p - 1.
  apply or_iff_not_imp_right.2
  intro h4
  -- Consider the possible remainders of p when divided by 4.
  have : p % 4 = 1 ∨ p % 4 = 3 := by
    -- Since p is a prime and p ≥ 5, p modulo 4 can only be 1 or 3.
    have : p % 4 = 1 ∨ p % 4 = 3 := by
      cases' h.eq_two_or_odd with h2 h2
      · exfalso
        -- If p were 2, it would contradict p ≥ 5.
        linarith
      · -- Since p is odd, p % 4 can only be 1 or 3.
        omega
    exact this
  -- Case analysis on the possible remainders of p modulo 4.
  rcases this with (h1 | h1) <;>
  -- Simplify the expressions modulo 4 and check divisibility.
  simp [h1, Nat.dvd_iff_mod_eq_zero, Nat.add_mod, Nat.mod_eq_of_lt, Nat.mod_eq_of_lt,
    Nat.sub_eq_zero_of_le, Nat.succ_le_iff] at h4 ⊢
  <;> omega
