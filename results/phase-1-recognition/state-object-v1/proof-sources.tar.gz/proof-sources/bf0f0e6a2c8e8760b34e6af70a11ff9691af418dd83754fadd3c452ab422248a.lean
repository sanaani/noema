import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $a^2c+b^2a+c^2b-3abc\geq 0$ for positive real numbers $a, b, c$. -/
theorem lean_workbook_8142 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : a^2 * c + b^2 * a + c^2 * b - 3 * a * b * c ≥ 0  := by
  /-
  To prove that \(a^2c + b^2a + c^2b - 3abc \geq 0\) for positive real numbers \(a, b, c\), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the non-negativity of the given expression by leveraging the non-negativity of squares and the given positive conditions on \(a, b, c\).
  -/
  -- Use the nlinarith tactic to handle the inequality. This tactic will automatically deduce the non-negativity of the expression by leveraging the non-negativity of squares and the given positive conditions on a, b, c.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_pos ha hb, mul_pos hb hc, mul_pos hc ha, sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a)]
