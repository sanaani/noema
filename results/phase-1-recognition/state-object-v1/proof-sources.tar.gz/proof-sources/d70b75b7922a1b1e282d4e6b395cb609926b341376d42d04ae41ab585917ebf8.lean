import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given non-negative real numbers $a,b,c,d$ satisfied $a+b+c+d\leqslant 3$ . Prove that $2a+3b^{2} +4c^{3} +5d^{4} \leqslant 405$ -/
theorem lean_workbook_plus_40576 (a b c d : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) (hab : a + b + c + d ≤ 3) : 2 * a + 3 * b^2 + 4 * c^3 + 5 * d^4 ≤ 405   := by
  /-
  Given non-negative real numbers \(a, b, c, d\) such that \(a + b + c + d \leq 3\), we need to prove that \(2a + 3b^2 + 4c^3 + 5d^4 \leq 405\). The proof involves using non-linear arithmetic to verify the inequality.
  -/
  -- Use non-linear arithmetic to verify the inequality.
  -- We provide specific inequalities to help the solver.
  nlinarith [pow_nonneg ha 1, pow_nonneg hb 1, pow_nonneg hc 1, pow_nonneg hd 1,
    pow_nonneg ha 2, pow_nonneg hb 2, pow_nonneg hc 2, pow_nonneg hd 2,
    pow_nonneg ha 3, pow_nonneg hb 3, pow_nonneg hc 3, pow_nonneg hd 3,
    pow_nonneg ha 4, pow_nonneg hb 4, pow_nonneg hc 4, pow_nonneg hd 4]
