import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a, b, c> 0 $ . Prove that \n$$ab+bc+ca +\frac{a^3+b^3+c^3}{a+b+c} \ge a^2+b^2+c^2+\frac{3(a+b-c)(b+c-a)(c+a-b)}{a+b+c}$$ -/
theorem lean_workbook_plus_23187 :  ∀ a b c : ℝ, a > 0 ∧ b > 0 ∧ c > 0 ∧ a + b > c ∧ a + c > b ∧ b + c > a →  a * b + b * c + c * a + (a ^ 3 + b ^ 3 + c ^ 3) / (a + b + c) ≥ a ^ 2 + b ^ 2 + c ^ 2 + 3 * (a + b - c) * (b + c - a) * (c + a - b) / (a + b + c)   := by
  /-
  Given \( a, b, c > 0 \), we need to prove that:
  \[ ab + bc + ca + \frac{a^3 + b^3 + c^3}{a + b + c} \ge a^2 + b^2 + c^2 + \frac{3(a + b - c)(b + c - a)(c + a - b)}{a + b + c} \]
  -/
  intro a b c h
  have h₁ : 0 < a + b + c := by linarith
  have h₂ : 0 < a * b := by nlinarith
  have h₃ : 0 < b * c := by nlinarith
  have h₄ : 0 < c * a := by nlinarith
  field_simp [h₁]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    ring_nf
  try nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_self_nonneg (a - b + c), mul_self_nonneg (b - c + a), mul_self_nonneg (c - a + b)]
