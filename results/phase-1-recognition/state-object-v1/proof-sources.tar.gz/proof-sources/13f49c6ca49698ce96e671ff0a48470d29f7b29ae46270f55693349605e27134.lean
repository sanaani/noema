import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let be $ x,y,z>0$ such that $ x^2+y^2+z^2=1$ . Show that : \n\n $ \frac{x^2(2x^2+1)}{3x^2+2yz}+\frac{y^2(2y^2+1)}{3y^2+2zx}+\frac{z^2(2z^2+1)}{3z^2+2xy}\ge 1$ -/
theorem lean_workbook_45636 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) (hx1 : x^2 + y^2 + z^2 = 1) : (x^2 * (2 * x^2 + 1) / (3 * x^2 + 2 * y * z) + y^2 * (2 * y^2 + 1) / (3 * y^2 + 2 * z * x) + z^2 * (2 * z^2 + 1) / (3 * z^2 + 2 * x * y)) ≥ 1  := by
  /-
  Given \( x, y, z > 0 \) such that \( x^2 + y^2 + z^2 = 1 \), we need to show that:
  \[
  \frac{x^2(2x^2 + 1)}{3x^2 + 2yz} + \frac{y^2(2y^2 + 1)}{3y^2 + 2zx} + \frac{z^2(2z^2 + 1)}{3z^2 + 2xy} \ge 1
  \]
  To prove this, we will use the fact that each term in the sum is non-negative and apply basic algebraic inequalities.
  -/
  have h1 : 0 < x * y := by
    -- Since x and y are positive, their product is also positive.
    apply mul_pos hx hy
  have h2 : 0 < x * z := by
    -- Since x and z are positive, their product is also positive.
    apply mul_pos hx hz
  have h3 : 0 < y * z := by
    -- Since y and z are positive, their product is also positive.
    apply mul_pos hy hz
  -- Use the fact that each term is non-negative and apply basic algebraic inequalities to prove the inequality.
  have h4 : x^2 * (2 * x^2 + 1) / (3 * x^2 + 2 * y * z) ≥ x^2 := by
    -- Apply the division inequality to show that the first term is at least x^2.
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr
    nlinarith [sq_nonneg (x - y), sq_nonneg (x - z), sq_nonneg (y - z)]
  have h5 : y^2 * (2 * y^2 + 1) / (3 * y^2 + 2 * z * x) ≥ y^2 := by
    -- Apply the division inequality to show that the second term is at least y^2.
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr
    nlinarith [sq_nonneg (x - y), sq_nonneg (x - z), sq_nonneg (y - z)]
  have h6 : z^2 * (2 * z^2 + 1) / (3 * z^2 + 2 * x * y) ≥ z^2 := by
    -- Apply the division inequality to show that the third term is at least z^2.
    rw [ge_iff_le]
    apply (le_div_iff₀ (by nlinarith)).mpr
    nlinarith [sq_nonneg (x - y), sq_nonneg (x - z), sq_nonneg (y - z)]
  -- Sum the inequalities to get the final result.
  nlinarith
