import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let a,b,c > 0 .Prove that : \n\ni, $ \frac {a}{a + 2b} + \frac {b}{b + 2c} + \frac {c}{c + 2a}\leq \frac {3(a^2 + b^2 + c^2)}{(a + b + c)^2}$ \n\n$ \Longleftrightarrow \sum{\left(1-\frac{a}{a+2b}\right)}\geq 3-\frac{3(a^2+b^2+c^2)}{(a+b+c)^2}=\frac{6(ab+bc+ca)}{(a+b+c)^2}$ \n\n$ \Longleftrightarrow \frac{b}{a+2b}+\frac{c}{b+2c}+\frac{a}{c+2a}\geq \frac{3(ab+bc+ca)}{(a+b+c)^2}$ -/
theorem lean_workbook_56877 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : (a / (a + 2 * b) + b / (b + 2 * c) + c / (c + 2 * a) ≤ (3 * (a ^ 2 + b ^ 2 + c ^ 2)) / (a + b + c) ^ 2) ↔ (b / (a + 2 * b) + c / (b + 2 * c) + a / (c + 2 * a) ≥ (3 * (a * b + b * c + c * a)) / (a + b + c) ^ 2)  := by
  /-
  We need to prove the equivalence of two inequalities involving the fractions \(\frac{a}{a + 2b}\), \(\frac{b}{b + 2c}\), and \(\frac{c}{c + 2a}\). The first inequality states that the sum of these fractions is less than or equal to \(\frac{3(a^2 + b^2 + c^2)}{(a + b + c)^2}\). The second inequality states that the sum of the fractions \(\frac{b}{a + 2b}\), \(\frac{c}{b + 2c}\), and \(\frac{a}{c + 2a}\) is greater than or equal to \(\frac{3(ab + bc + ca)}{(a + b + c)^2}\).
  To prove this equivalence, we will show that each inequality implies the other.
  1. **First Direction**: Assume the first inequality holds. We need to show that the second inequality holds.
  2. **Second Direction**: Assume the second inequality holds. We need to show that the first inequality holds.
  -/
  constructor
  -- First direction: Assume the left-hand side inequality holds, prove the right-hand side inequality.
  intro h
  have h₁ : 0 < a + b + c := by linarith
  have h₂ : 0 < a + 2 * b := by linarith
  have h₃ : 0 < b + 2 * c := by linarith
  have h₄ : 0 < c + 2 * a := by linarith
  field_simp [h₁, h₂, h₃, h₄] at h ⊢
  (try rw [div_le_div_iff₀ (by positivity) (by positivity)] at h) ⊢
  ring_nf at h ⊢
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
  -- Second direction: Assume the right-hand side inequality holds, prove the left-hand side inequality.
  intro h
  have h₁ : 0 < a + b + c := by linarith
  have h₂ : 0 < a + 2 * b := by linarith
  have h₃ : 0 < b + 2 * c := by linarith
  have h₄ : 0 < c + 2 * a := by linarith
  field_simp [h₁, h₂, h₃, h₄] at h ⊢
  (try rw [div_le_div_iff₀ (by positivity) (by positivity)] at h) ⊢
  ring_nf at h ⊢
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
