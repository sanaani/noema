import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $(a + b + c)^2 \ge 3(ab + bc + ca)$. -/
theorem lean_workbook_plus_9114 (a b c : ℝ) : (a + b + c) ^ 2 ≥ 3 * (a * b + b * c + c * a)   := by
  /-
  To prove the inequality \((a + b + c)^2 \ge 3(ab + bc + ca)\), we start by expanding the left-hand side and simplifying the expression. We then use the non-negativity of squares to establish the inequality.
  1. Expand \((a + b + c)^2\) to get \(a^2 + b^2 + c^2 + 2ab + 2bc + 2ca\).
  2. Rearrange the inequality to compare it with \(3(ab + bc + ca)\).
  3. Notice that \(a^2 + b^2 + c^2 + 2ab + 2bc + 2ca \ge 3(ab + bc + ca)\) can be rewritten as \(a^2 + b^2 + c^2 \ge ab + bc + ca\).
  4. This inequality holds because \(a^2 + b^2 + c^2 - ab - bc - ca \ge 0\), which can be derived from the non-negativity of the squares of the differences \(a - b\), \(b - c\), and \(c - a\).
  -/
  -- Expand and simplify the left-hand side of the inequality.
  ring_nf
  -- Use the non-negativity of squares to establish the inequality.
  -- Specifically, we use the fact that the squares of the differences (a - b), (b - c), and (c - a) are non-negative.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
