import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that the following inequality holds for nonnegative reals: \n\n $(a+b+c+d)^3\geq 16(abc+bcd+cda+dab).$ -/
theorem lean_workbook_plus_25569 (a b c d : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) : (a + b + c + d) ^ 3 ≥ 16 * (a * b * c + b * c * d + c * d * a + d * a * b)   := by
  /-
  To prove the inequality \((a+b+c+d)^3 \geq 16(abc+bcd+cda+dab)\) for nonnegative reals \(a, b, c, d\), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the desired inequality by considering the non-negativity of various expressions derived from \(a, b, c,\) and \(d\).
  -/
  -- Use nlinarith to handle the inequality by considering the non-negativity of various expressions.
  nlinarith [sq_nonneg (a + b + c + d), sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d),
    sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d), sq_nonneg (a + b - c - d),
    sq_nonneg (a + c - b - d), sq_nonneg (a + d - b - c), sq_nonneg (b + c - a - d),
    sq_nonneg (b + d - a - c), sq_nonneg (c + d - a - b)]
