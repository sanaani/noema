import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that if $a \equiv b \pmod m$ and $n | m$ , then $a \equiv b \pmod n$ -/
theorem lean_workbook_plus_23949 (a b m n : ℤ) (h₁ : a ≡ b [ZMOD m]) (h₂ : n ∣ m) : a ≡ b [ZMOD n]   := by
  /-
  Given that \( a \equiv b \pmod{m} \) and \( n \) divides \( m \), we need to show that \( a \equiv b \pmod{n} \). By the definition of modular equivalence, \( a \equiv b \pmod{m} \) implies that \( m \) divides \( a - b \). Since \( n \) divides \( m \), there exists an integer \( k \) such that \( m = nk \). Therefore, \( a - b \) is divisible by \( m \), and since \( m = nk \), it follows that \( a - b \) is also divisible by \( n \). Hence, \( a \equiv b \pmod{n} \).
  -/
  -- Rewrite the modular equivalence in terms of divisibility.
  rw [Int.ModEq] at h₁ ⊢
  -- Use the transitivity of divisibility to show that if n divides m and m divides (a - b), then n divides (a - b).
  exact (Int.ModEq.of_dvd h₂ h₁)
