import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $\binom{2}{2}=1=\binom{3}{3}$ -/
theorem lean_workbook_56282 : choose 2 2 = 1 ∧ choose 3 3 = 1  := by
  /-
  We need to prove that the binomial coefficients \(\binom{2}{2}\) and \(\binom{3}{3}\) both equal 1. This can be shown by using the definition of binomial coefficients, which states that \(\binom{n}{n} = 1\) for any non-negative integer \(n\). Specifically, for \(n = 2\) and \(n = 3\), we have:
  \[
  \binom{2}{2} = 1 \quad \text{and} \quad \binom{3}{3} = 1
  \]
  -/
  constructor
  -- Prove that \(\binom{2}{2} = 1\)
  -- By definition, \(\binom{2}{2} = \frac{2!}{2!(2-2)!} = \frac{2!}{2! \cdot 0!} = \frac{2 \cdot 1}{1 \cdot 1} = 1\)
  simp [choose]
  -- Prove that \(\binom{3}{3} = 1\)
  -- By definition, \(\binom{3}{3} = \frac{3!}{3!(3-3)!} = \frac{3!}{3! \cdot 0!} = \frac{3 \cdot 2 \cdot 1}{1 \cdot 1 \cdot 1} = 1\)
  simp [choose]
