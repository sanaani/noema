import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- 14 choose two is $\frac{14!}{12!*2!}$ -/
theorem lean_workbook_plus_24728 : (choose 14 2 : ℚ) = (factorial 14)/(factorial 12 * factorial 2)   := by
  /-
  The theorem states that the binomial coefficient \(\binom{14}{2}\) is equal to \(\frac{14!}{12! \cdot 2!}\). This can be verified by directly calculating the binomial coefficient using the formula for binomial coefficients, which is given by \(\binom{n}{k} = \frac{n!}{k!(n-k)!}\). In this case, \(n = 14\) and \(k = 2\), so we have \(\binom{14}{2} = \frac{14!}{2!(14-2)!} = \frac{14!}{2! \cdot 12!}\).
  -/
  -- Directly use the definition of the binomial coefficient to verify the equality.
  rfl
