import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c>0$ and satify condition $3a+4c\geq 18$. Prove that: $a+b+c+\frac{6}{abc}\geq 7$. -/
theorem lean_workbook_plus_65508 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) (h : 3 * a + 4 * c ≥ 18) : a + b + c + 6 / (a * b * c) ≥ 7   := by
  /-
  Given \(a, b, c > 0\) and satisfying the condition \(3a + 4c \geq 18\), we need to prove that:
  \[ a + b + c + \frac{6}{abc} \geq 7. \]
  Since \(a, b, c > 0\) and \(a \cdot b \cdot c = 1\), we can simplify \(\frac{6}{abc}\) to \(6\). Thus, the inequality becomes:
  \[ a + b + c + 6 \geq 7. \]
  Given the condition \(3a + 4c \geq 18\), we can infer that \(a + b + c \geq 3\) because \(3a + 4c \geq 18\) implies \(a + b + c \geq 3\) by linear arithmetic. Therefore, adding 6 to both sides of the inequality \(a + b + c \geq 3\) results in:
  \[ a + b + c + 6 \geq 7. \]
  Thus, the inequality \(a + b + c + \frac{6}{abc} \geq 7\) holds.
  -/
  -- Simplify the expression using the fact that a * b * c = 1
  field_simp [habc, mul_pos ha hb, mul_pos ha hc, mul_pos hb hc]
  -- Use non-linear arithmetic to prove the inequality
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (b - c)]
