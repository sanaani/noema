import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for all real numbers $a,b,c$ \((a^4+b^4+c^4) \ge max((a^3b+b^3c+c^3a),(ab^3+bc^3+ca^3))\) -/
theorem lean_workbook_55402 (a b c : ℝ) : (a^4+b^4+c^4) ≥ max (a^3*b+b^3*c+c^3*a) (a*b^3+b*c^3+c*a^3)  := by
  /-
  To prove that for all real numbers \(a, b, c\), \((a^4 + b^4 + c^4) \ge \max((a^3b + b^3c + c^3a), (ab^3 + bc^3 + ca^3))\), we consider two cases based on the comparison between \(a^3b + b^3c + c^3a\) and \(ab^3 + bc^3 + ca^3\). In each case, we use the properties of the maximum function and the non-negativity of squares to establish the inequality.
  1. **Case 1: \(a^3b + b^3c + c^3a \ge ab^3 + bc^3 + ca^3\)**
     - By the definition of the maximum function, \(\max((a^3b + b^3c + c^3a), (ab^3 + bc^3 + ca^3)) = a^3b + b^3c + c^3a\).
     - We need to show that \((a^4 + b^4 + c^4) \ge a^3b + b^3c + c^3a\).
     - Using the non-negativity of squares, we can derive the inequality by considering the squares of various differences involving \(a, b,\) and \(c\).
  2. **Case 2: \(a^3b + b^3c + c^3a < ab^3 + bc^3 + ca^3\)**
     - By the definition of the maximum function, \(\max((a^3b + b^3c + c^3a), (ab^3 + bc^3 + ca^3)) = ab^3 + bc^3 + ca^3\).
     - We need to show that \((a^4 + b^4 + c^4) \ge ab^3 + bc^3 + ca^3\).
     - Using the non-negativity of squares, we can derive the inequality by considering the squares of various differences involving \(a, b,\) and \(c\).
  -/
  -- Consider the two cases based on the comparison between the expressions.
  cases' le_total (a^3 * b + b^3 * c + c^3 * a) (a * b^3 + b * c^3 + c * a^3) with h h <;>
  -- Simplify the expression based on the comparison result.
  simp_all [max_eq_right, max_eq_left]
  -- Use the non-negativity of squares to establish the inequality in each case.
  all_goals nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a^2 - b^2), sq_nonneg (b^2 - c^2), sq_nonneg (c^2 - a^2),
    sq_nonneg (a^2 - a * b), sq_nonneg (b^2 - b * c), sq_nonneg (c^2 - c * a),
    sq_nonneg (a * b - b * c), sq_nonneg (b * c - c * a), sq_nonneg (c * a - a * b)]
