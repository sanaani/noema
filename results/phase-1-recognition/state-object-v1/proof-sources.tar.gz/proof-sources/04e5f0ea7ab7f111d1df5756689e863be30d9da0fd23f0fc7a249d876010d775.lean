import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a,b,c\ge 0$ and $ a + b + c = 1$ ,prove that $ a^3 + b^3 + c^3 + 6abc\ge \frac {1}{4}$ -/
theorem lean_workbook_38211 (a b c : ℝ) (ha : a ≥ 0 ∧ b ≥ 0 ∧ c ≥ 0 ∧ a + b + c = 1) : a^3 + b^3 + c^3 + 6 * a * b * c ≥ 1 / 4  := by
  /-
  Given \( a, b, c \ge 0 \) and \( a + b + c = 1 \), we need to prove that \( a^3 + b^3 + c^3 + 6abc \ge \frac{1}{4} \).
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which is capable of handling inequalities involving polynomials. Specifically, we use the fact that the squares of real numbers are non-negative, which helps in establishing the required inequality.
  -/
  -- Use nlinarith to handle the inequality involving polynomials.
  -- The non-negativity of squares of differences and sums helps in establishing the inequality.
  nlinarith [sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a + b + c - 1)]
