import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a, b,c$ be real numbers such that $a^2+ b^2+c^2=1 $. Show that\n\n $-\frac{1}{2} \le ab+bc+ca+|(a-b)(b-c)(c-a)| \le 1$ -/
theorem lean_workbook_23477 : ∀ a b c : ℝ, a^2 + b^2 + c^2 = 1 → (-1/2 ≤ a * b + b * c + c * a + |(a - b) * (b - c) * (c - a)| ∧ a * b + b * c + c * a + |(a - b) * (b - c) * (c - a)| ≤ 1)  := by
  /-
  Given real numbers \(a\), \(b\), and \(c\) such that \(a^2 + b^2 + c^2 = 1\), we need to show that:
  \[
  -\frac{1}{2} \le ab + bc + ca + |(a - b)(b - c)(c - a)| \le 1
  \]
  To prove this, we consider different cases based on the signs of \((a - b)\), \((b - c)\), and \((c - a)\). For each case, we simplify the expression using the properties of absolute values and then use algebraic inequalities to establish the bounds.
  -/
  intro a b c h
  constructor
  next =>
    -- Consider different cases based on the signs of (a - b), (b - c), and (c - a)
    cases' le_total 0 ((a - b) * (b - c) * (c - a)) with h₀ h₀ <;>
      cases' le_total 0 (a * b + b * c + c * a) with h₁ h₁ <;>
        cases' le_total 0 (a - b) with h₂ h₂ <;>
          cases' le_total 0 (b - c) with h₃ h₃ <;>
            cases' le_total 0 (c - a) with h₄ h₄ <;>
              -- Simplify the expression using the properties of absolute values
              simp_all only [abs_of_nonneg, abs_of_nonpos, sub_nonneg, sub_nonpos] <;>
                -- Use algebraic inequalities to establish the lower bound
                nlinarith [h, sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
  next =>
    -- Consider different cases based on the signs of (a - b), (b - c), and (c - a)
    cases' le_total 0 ((a - b) * (b - c) * (c - a)) with h₀ h₀ <;>
      cases' le_total 0 (a * b + b * c + c * a) with h₁ h₁ <;>
        cases' le_total 0 (a - b) with h₂ h₂ <;>
          cases' le_total 0 (b - c) with h₃ h₃ <;>
            cases' le_total 0 (c - a) with h₄ h₄ <;>
              -- Simplify the expression using the properties of absolute values
              simp_all only [abs_of_nonneg, abs_of_nonpos, sub_nonneg, sub_nonpos] <;>
                -- Use algebraic inequalities to establish the upper bound
                nlinarith [h, sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
