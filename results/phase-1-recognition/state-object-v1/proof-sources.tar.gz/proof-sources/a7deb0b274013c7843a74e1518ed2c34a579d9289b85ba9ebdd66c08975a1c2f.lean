import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $f(x)-g(x)=\\dfrac{(x+1)(\\sqrt x-1)^2}{x}\\ge0$ -/
theorem lean_workbook_2359 (x : ℝ) (hx : 0 < x) : (x + 1) * (Real.sqrt x - 1) ^ 2 / x ≥ 0  := by
  /-
  To prove that \( f(x) - g(x) = \frac{(x+1)(\sqrt{x}-1)^2}{x} \ge 0 \), we need to show that the expression \(\frac{(x+1)(\sqrt{x}-1)^2}{x}\) is non-negative. This can be achieved by demonstrating that the numerator \((x+1)(\sqrt{x}-1)^2\) is non-negative and the denominator \(x\) is positive.
  1. **Numerator Analysis**:
     - \((x+1)\) is positive because \(x > 0\).
     - \((\sqrt{x}-1)^2\) is a square of a real number, hence it is non-negative.
  2. **Denominator Analysis**:
     - \(x\) is positive by the given condition \(x > 0\).
  Since both the numerator and the denominator are non-negative and positive respectively, the fraction \(\frac{(x+1)(\sqrt{x}-1)^2}{x}\) is non-negative.
  -/
  -- Apply the theorem that a fraction is non-negative if both the numerator and the denominator are non-negative.
  apply div_nonneg
  -- Show that the numerator (x+1)(Real.sqrt x - 1)^2 is non-negative.
  <;> nlinarith [Real.sqrt_nonneg x, sq_nonneg (Real.sqrt x - 1)]
