import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c>0$ ,prove $ab^2+bc^2+ca^2$ ≥ $abc+2ac^2-c^3$ . -/
theorem lean_workbook_47346 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : a * b ^ 2 + b * c ^ 2 + c * a ^ 2 ≥ a * b * c + 2 * a * c ^ 2 - c ^ 3  := by
  /-
  To prove the inequality \( ab^2 + bc^2 + ca^2 \geq abc + 2ac^2 - c^3 \) for \( a, b, c > 0 \), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the desired inequality by considering the non-negativity of squared terms and the positivity of the variables.
  -/
  -- Use the nlinarith tactic to handle the inequality. This tactic will consider the non-negativity of squared terms and the positivity of the variables to deduce the desired inequality.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_pos ha hb, mul_pos hb hc, mul_pos hc ha,
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a), mul_self_nonneg (a - b + c), mul_self_nonneg (b - c + a),
    mul_self_nonneg (c - a + b)]
