import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a, b, c, d $ be negative integers. Prove that $ (a+b+c+d)^{4} \ge abcd. $ -/
theorem lean_workbook_36306 (a b c d : ℤ) (hab : a < 0) (hbc : b < 0) (hcd : c < 0) (hda : d < 0) : (a + b + c + d) ^ 4 ≥ a * b * c * d  := by
  /-
  Given negative integers \(a, b, c, d\), we need to prove that \((a + b + c + d)^4 \ge abcd\). Since \(a, b, c, d\) are all negative, their sum \(a + b + c + d\) is also negative. The fourth power of a negative number is positive, and the product of four negative numbers is also positive. Therefore, the inequality holds due to the properties of powers and products of negative numbers.
  -/
  -- Expand the fourth power of the sum of a, b, c, and d.
  ring_nf
  -- Use non-linear arithmetic to prove the inequality, leveraging the properties of negative numbers and their products.
  nlinarith [mul_pos_of_neg_of_neg hab hbc, mul_pos_of_neg_of_neg hab hcd, mul_pos_of_neg_of_neg hab hda, mul_pos_of_neg_of_neg hbc hcd, mul_pos_of_neg_of_neg hbc hda, mul_pos_of_neg_of_neg hcd hda]
