import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Calculate $ 12\times3 + 4\times5 $ -/
theorem lean_workbook_plus_48984 (h₁ : 12 * 3 + 4 * 5 = 56) : 12 * 3 + 4 * 5 = 56   := by
  /-
  We need to verify that the expression \( 12 \times 3 + 4 \times 5 \) equals 56. Given the hypothesis \( h₁ \) which states that \( 12 \times 3 + 4 \times 5 = 56 \), we can directly apply this hypothesis to confirm the equality.
  -/
  -- Apply the given hypothesis h₁ to confirm the equality.
  apply h₁
