import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- So it's enough to prove $\sqrt3\leq\frac{5a-6}{3a-4}$ which is true $\forall a \in [\sqrt{3},2]$ -/
theorem lean_workbook_plus_14058 :
  ∀ a ∈ Set.Icc (Real.sqrt 3) 2, (Real.sqrt 3 ≤ (5 * a - 6) / (3 * a - 4))   := by
  /-
  To prove that for any \( a \) in the interval \([ \sqrt{3}, 2 ]\), \(\sqrt{3} \leq \frac{5a - 6}{3a - 4}\), we start by analyzing the given interval and the inequality. The interval \([ \sqrt{3}, 2 ]\) is a closed interval where \( \sqrt{3} \approx 1.732 \) and \( 2 \) are the endpoints. We need to show that the inequality holds for all \( a \) in this interval.
  1. **Interval Analysis**: The interval \([ \sqrt{3}, 2 ]\) is a subset of the real numbers where \( \sqrt{3} \leq a \leq 2 \).
  2. **Inequality Analysis**: We need to verify that \(\sqrt{3} \leq \frac{5a - 6}{3a - 4}\) for all \( a \) in the interval \([ \sqrt{3}, 2 ]\).
  3. **Numerical Verification**: By evaluating the inequality at the endpoints and within the interval, we can confirm its validity. For \( a = \sqrt{3} \), we check if \(\sqrt{3} \leq \frac{5\sqrt{3} - 6}{3\sqrt{3} - 4}\). Similarly, for \( a = 2 \), we check if \(\sqrt{3} \leq \frac{5 \cdot 2 - 6}{3 \cdot 2 - 4}\).
  4. **Conclusion**: Through numerical evaluation and simplification, we can confirm that the inequality holds for all \( a \) in the interval \([ \sqrt{3}, 2 ]\).
  -/
  -- Introduce the variable `a` and the hypothesis `h` that `a` is in the interval [sqrt(3), 2]
  intro a h
  -- Normalize the numbers in the hypothesis `h` to ensure they are in the correct form
  norm_num at h
  -- Use linear arithmetic to prove the inequality
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [Real.sqrt_nonneg 3, sq_sqrt (show 0 ≤ 3 by norm_num)]
