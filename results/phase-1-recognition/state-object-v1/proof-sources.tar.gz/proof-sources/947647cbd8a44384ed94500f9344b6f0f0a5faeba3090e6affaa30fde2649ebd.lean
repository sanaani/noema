import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- prove that $(a+b+c+d)^3 \geq 16(abc + bcd + acd + adb)$ if $a,b,c,d$ are non negative numbers -/
theorem lean_workbook_plus_11487 (a b c d : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) (hd : d ≥ 0) : (a + b + c + d) ^ 3 ≥ 16 * (a * b * c + b * c * d + a * c * d + a * b * d)   := by
  /-
  To prove that \((a + b + c + d)^3 \geq 16(abc + bcd + acd + adb)\) for non-negative numbers \(a, b, c, d\), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the required inequality by considering the non-negativity of various expressions.
  -/
  -- Use nlinarith to handle the inequality. It will consider the non-negativity of various expressions to deduce the required inequality.
  nlinarith [sq_nonneg (a + b + c + d), sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d),
    mul_nonneg ha hb, mul_nonneg ha hc, mul_nonneg ha hd, mul_nonneg hb hc, mul_nonneg hb hd, mul_nonneg hc hd,
    sq_nonneg (a + b - c - d), sq_nonneg (a + c - b - d), sq_nonneg (a + d - b - c), sq_nonneg (b + c - a - d), sq_nonneg (b + d - a - c), sq_nonneg (c + d - a - b)]
