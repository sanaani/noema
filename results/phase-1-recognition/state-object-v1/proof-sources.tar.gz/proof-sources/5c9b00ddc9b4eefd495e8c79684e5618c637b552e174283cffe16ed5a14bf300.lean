import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given $n > \frac{25}{12}$, prove that $\sqrt{n(n+2)} > n + \frac{5}{6}$ -/
theorem lean_workbook_53725 (n : ℝ) (h : n > 25 / 12) : Real.sqrt (n * (n + 2)) > n + 5 / 6  := by
  /-
  Given \( n > \frac{25}{12} \), we need to prove that \( \sqrt{n(n+2)} > n + \frac{5}{6} \).
  1. Start by noting that \( n > \frac{25}{12} \).
  2. Use the property of the square root function to rewrite the inequality \( \sqrt{n(n+2)} > n + \frac{5}{6} \) in a form that can be directly compared.
  3. Apply the inequality \( \sqrt{n(n+2)} > n + \frac{5}{6} \) by squaring both sides and simplifying.
  4. Verify that the inequality holds by using algebraic manipulations and the given condition \( n > \frac{25}{12} \).
  -/
  -- Use the property of the square root function to rewrite the inequality
  have h₁ : Real.sqrt (n * (n + 2)) > n + 5 / 6 := by
    -- Apply the inequality by squaring both sides and simplifying
    apply Real.lt_sqrt_of_sq_lt
    -- Verify that the inequality holds by using algebraic manipulations
    nlinarith [sq_sqrt (show 0 ≤ n * (n + 2) from by nlinarith),
      sq_nonneg (n - 25 / 12),
      sq_nonneg (n + 25 / 12)]
  -- Conclude the proof by using the established inequality
  exact h₁
