import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b\ge 0$ and $a+b=1.$ Prove that $a^2+b^2\le \frac{7}{16}+a^5+b^5$ -/
theorem lean_workbook_3393 (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) : a^2 + b^2 ≤ 7 / 16 + a^5 + b^5  := by
  /-
  Given \( a, b \ge 0 \) and \( a + b = 1 \), we need to prove that \( a^2 + b^2 \le \frac{7}{16} + a^5 + b^5 \).
  1. Express \( b \) in terms of \( a \): Since \( a + b = 1 \), we have \( b = 1 - a \).
  2. Substitute \( b = 1 - a \) into the inequality:
     \[
     a^2 + (1 - a)^2 \le \frac{7}{16} + a^5 + (1 - a)^5
     \]
  3. Expand both sides of the inequality:
     \[
     a^2 + (1 - a)^2 = a^2 + (1 - 2a + a^2) = 2a^2 - 2a + 1
     \]
     \[
     \frac{7}{16} + a^5 + (1 - a)^5 = \frac{7}{16} + a^5 + (1 - 5a + 10a^2 - 10a^3 + 5a^4 - a^5)
     \]
  4. Combine the terms:
     \[
     2a^2 - 2a + 1 \le \frac{7}{16} + a^5 + 1 - 5a + 10a^2 - 10a^3 + 5a^4 - a^5
     \]
  5. Simplify the right-hand side:
     \[
     \frac{7}{16} + 1 - 5a + 10a^2 - 10a^3 + 5a^4 - a^5 = \frac{23}{16} - 5a + 10a^2 - 10a^3 + 5a^4 - a^5
     \]
  6. Compare the simplified expressions:
     \[
     2a^2 - 2a + 1 \le \frac{23}{16} - 5a + 10a^2 - 10a^3 + 5a^4 - a^5
     \]
  7. Use non-linear arithmetic to verify the inequality holds for all \( 0 \le a \le 1 \).
  -/
  -- Express b in terms of a
  have hb' : b = 1 - a := by linarith
  -- Substitute b = 1 - a into the inequality
  rw [hb']
  -- Expand and simplify both sides of the inequality
  ring_nf
  -- Use non-linear arithmetic to verify the inequality
  nlinarith [sq_nonneg (a - 1 / 2), sq_nonneg (a + 1 / 2), sq_nonneg (a - 1 / 2 + 1 / 2),
    sq_nonneg (a - 1 / 2 - 1 / 2)]
