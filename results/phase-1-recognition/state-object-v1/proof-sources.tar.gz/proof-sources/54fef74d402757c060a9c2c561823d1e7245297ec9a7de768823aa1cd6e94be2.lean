import Mathlib
import Aesop

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given $ A\cup B = A\cap B$ , prove that $ A = B$ . -/
theorem lean_workbook_plus_23627 (A B : Set α) (h : A ∪ B = A ∩ B) : A = B   := by
  /-
  To prove that \( A = B \) given \( A \cup B = A \cap B \), we will show that for any element \( x \), \( x \in A \) if and only if \( x \in B \).
  1. Start by considering an arbitrary element \( x \).
  2. Rewrite the given equality \( A \cup B = A \cap B \) in terms of membership: \( x \in A \cup B \leftrightarrow x \in A \cap B \).
  3. Simplify the membership conditions using set operations.
  4. Use logical reasoning to conclude that \( x \in A \) if and only if \( x \in B \).
  -/
  -- Consider an arbitrary element x.
  ext x
  -- Rewrite the given equality in terms of membership.
  have h₁ : x ∈ A ∪ B ↔ x ∈ A ∩ B := by rw [h]
  -- Simplify the membership conditions using set operations.
  simp only [Set.mem_union, Set.mem_inter_iff] at h₁
  -- Use logical reasoning to conclude that x ∈ A if and only if x ∈ B.
  tauto
