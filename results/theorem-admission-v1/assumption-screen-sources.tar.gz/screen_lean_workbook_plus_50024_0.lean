import Contradictions
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option linter.unusedVariables false
open BigOperators Real Nat Topology Rat
theorem screen_lean_workbook_plus_50024_0 (x y z : ℝ)
  (h₀ : 0 < abs (x - y))
  (h₁ : 0 < abs (y - z))
  (h₂ : 0 < abs (z - x))
  (h₃ : abs (x - y) ≥ abs (y - z))
  (h₄ : abs (y - z) ≥ abs (z - x))
  (h₅ : abs (z - x) ≥ 1) : False := by
  first
  | exact noema_5257 r₁ r₂ r₃ h₁ h₂ h₃ h₄
  | exact noema_63727 x y z k hx hy hz hk1 hk2
  | exact noema_product_squares a b c ha hb hc habc h
  | exact noema_68017 a b c ha hb hc habc h
  | exact noema_9657 a h h'
  | omega
  | nlinarith
#print axioms screen_lean_workbook_plus_50024_0
