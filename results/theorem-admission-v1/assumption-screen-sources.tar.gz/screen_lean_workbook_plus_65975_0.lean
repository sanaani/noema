import Contradictions
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option linter.unusedVariables false
open BigOperators Real Nat Topology Rat
theorem screen_lean_workbook_plus_65975_0 (f : ℝ → ℝ) (x a b : ℝ) (h₁ : a = (x + 1) / (x - 2)) (h₂ : b = (x - 2) / (x + 1)) (h₃ : f a + 3 * f b = x) (h₄ : f b + 3 * f a = -x + 1) : False := by
  first
  | exact noema_5257 r₁ r₂ r₃ h₁ h₂ h₃ h₄
  | exact noema_63727 x y z k hx hy hz hk1 hk2
  | exact noema_product_squares a b c ha hb hc habc h
  | exact noema_68017 a b c ha hb hc habc h
  | exact noema_9657 a h h'
  | omega
  | nlinarith
#print axioms screen_lean_workbook_plus_65975_0
