import Contradictions
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option linter.unusedVariables false
open BigOperators Real Nat Topology Rat
theorem screen_lean_workbook_plus_23440_0 (a b c d : ℝ) (h1 : abs (a - b) ≥ 1) (h2 : abs (b - c) ≥ 1) (h3 : abs (c - d) ≥ 1) (h4 : abs (d - a) ≥ 1) : False := by
  first
  | exact noema_5257 r₁ r₂ r₃ h₁ h₂ h₃ h₄
  | exact noema_63727 x y z k hx hy hz hk1 hk2
  | exact noema_product_squares a b c ha hb hc habc h
  | exact noema_68017 a b c ha hb hc habc h
  | exact noema_9657 a h h'
  | omega
  | nlinarith
#print axioms screen_lean_workbook_plus_23440_0
