import Contradictions
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option linter.unusedVariables false
open BigOperators Real Nat Topology Rat
theorem screen_lean_workbook_plus_78448_0 (x₁ x₂ m p : ℤ) (h₁ : x₁ * x₂ = p^2 + 1) (h₂ : x₁ + x₂ = -2*m) : False := by
  first
  | exact noema_5257 r₁ r₂ r₃ h₁ h₂ h₃ h₄
  | exact noema_63727 x y z k hx hy hz hk1 hk2
  | exact noema_product_squares a b c ha hb hc habc h
  | exact noema_68017 a b c ha hb hc habc h
  | exact noema_9657 a h h'
  | omega
  | nlinarith
#print axioms screen_lean_workbook_plus_78448_0
