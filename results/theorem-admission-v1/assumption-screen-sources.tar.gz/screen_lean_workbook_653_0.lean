import Contradictions
set_option autoImplicit false
set_option maxHeartbeats 100000
set_option linter.unusedVariables false
open BigOperators Real Nat Topology Rat
theorem screen_lean_workbook_653_0 (k : ℕ) (a : ℕ → ℕ) (a0 : a 0 = 0) (a1 : a 1 = 1) (a_rec : ∀ n, a (n + 1) = 4 * a n + a (n - 1)) : False := by
  first
  | exact noema_5257 r₁ r₂ r₃ h₁ h₂ h₃ h₄
  | exact noema_63727 x y z k hx hy hz hk1 hk2
  | exact noema_product_squares a b c ha hb hc habc h
  | exact noema_68017 a b c ha hb hc habc h
  | exact noema_9657 a h h'
  | omega
  | nlinarith
#print axioms screen_lean_workbook_653_0
